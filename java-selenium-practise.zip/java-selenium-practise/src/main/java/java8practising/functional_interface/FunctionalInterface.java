package java8practising.functional_interface;

public class FunctionalInterface {
    public static void main(String[] args) {
//        1.  //Write Anonymous inner class to implement method of MyInterface (FunctionalInterface)
//        MyInterface myInterface = new MyInterface() {
//            @Override
//            public void myMethod() {
//                System.out.println("hi this sravanthi");
//            }
//        };
//
//        //Call myMethod()
//        myInterface.myMethod();
//    }

  //2  //Write LAMBDA EXPRESSION to implement method of MyInterface (FunctionalInterface)
    MyInterface myInterface = () -> {
        System.out.println("hi this is anumula");
    };

    //Call myMethod()
           myInterface.myMethod();
 }
}
