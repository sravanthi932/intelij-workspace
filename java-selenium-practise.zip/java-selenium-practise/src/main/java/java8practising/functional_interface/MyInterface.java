package java8practising.functional_interface;

public interface MyInterface {
    public abstract void myMethod();
}
