package java8practising.unaryandbinary;

import java.util.function.Function;
import java.util.function.UnaryOperator;

public class UnaryPractise {
    public static void main(String args[])
    {
        UnaryOperator<Integer> xor = a -> a ^ 1;
        UnaryOperator<Integer> and = a -> a & 1;
        Function<Integer, Integer> compose = xor.andThen(and);
        System.out.println(compose.apply(2));
    }
}
