package java8practising.lambda;

import java.util.Arrays;
import java.util.Comparator;

public class SortStringArrayWithLocalClass {
    public static void main(String... args) {

        String[] stringArray = {"Sravanthi", "Hethvik", "Naveen"};


        //Create Local class
        class StringSort implements Comparator<String> {
            public int compare(String a, String b) {
                return a.compareTo(b);
            }
        }

        //Before Java 8 -  Sort String Using Local class - Without Lambda expression
        System.out.println("Before Java 8 - Sort StringArray using Using "
                + " > Local class - i.e. Without Lambda expression");
        Arrays.sort(stringArray, new StringSort());

        //Display StringArray
        for (String str : stringArray) {
            System.out.print(str + " ");
        }
    }
}
