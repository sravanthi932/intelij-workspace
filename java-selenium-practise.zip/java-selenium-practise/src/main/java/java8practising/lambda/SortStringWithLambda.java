package java8practising.lambda;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class SortStringWithLambda {
    public static void main(String... args) {

        //Declare StringArray
        String[] stringArray = { "sravanthi", "hethvik", "naveen" };


        //Convert String Array to String List
        List<String> stringList = Arrays.asList(stringArray);

        //In Java 8 - Sort StringList using > Lambda expression - in one line
        Collections.sort(stringList, (a, b) -> a.compareTo(b));

        //Display StringList
        System.out.println(stringList);

    }
}
