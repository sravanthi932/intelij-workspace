package java8practising.lambda;

import java.util.Arrays;

public class SortStringArraywithLambda {
    public static void main(String... args) {

        String[] stringArray = { "sravanthi", "hethvik", "naveen" };

        System.out.println("In Java 8 - Sort StringArray using > Lambda expression");

       //1.
        Arrays.sort(stringArray, (String a, String b) -> {
            return a.compareTo(b);
        });
        //2.
        Arrays.sort(stringArray, (a, b) -> {
            return a.compareTo(b);
        });

        // Display StringArray
        for (String str : stringArray) {
            System.out.print(str + " ");
        }

    }
}
