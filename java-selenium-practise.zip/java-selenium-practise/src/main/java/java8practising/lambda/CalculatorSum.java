package java8practising.lambda;

public class CalculatorSum {
    public static void main(String[] args) {

        // Provide implementation (definition) of sumMethod - using Lambda expression
        // A will be type Integer
        CalculatorInterface<Integer> sum = (Integer val1, Integer val2) -> {
            return val1 + val2;
        };

        // Call sumMethod
        Integer result = sum.sumMethod(2, 3);
        System.out.println(result); // 5
    }
}
@FunctionalInterface
interface CalculatorInterface<A> {
    public abstract A sumMethod(A val1, A val2);
}
