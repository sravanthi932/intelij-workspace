package java8practising.streams;

import java.util.*;
import java.util.stream.Stream;

public class ConvertArrayListOfIntegersToStreams {
    public static void main(String[] args) {

        //Stream<Integer> stream = Stream.of(1,2,3,4);

        System.out.println("1. Create list of Integer");
        List<Integer> listOfIntegers = new ArrayList<>();
        listOfIntegers.add(11);
        listOfIntegers.add(12);


        System.out.println("2. Convert list (ArrayList) of Integer to stream");
        Stream<Integer> streamOfInteger = listOfIntegers.stream();

        System.out.println("3. Display Stream of Integer");
        streamOfInteger.forEach(System.out::println);
    }
}
