package java8practising.streams;

import java.util.*;
import java.util.stream.Stream;

public class ConvertArrayListOfStringToStreams {
    public static void main(String[] args) {

        System.out.println("1. Create list of String");
        List<String> listOfStrings = new ArrayList<>();
        listOfStrings.add("naveen");
        listOfStrings.add("sravanthi");

        System.out.println("2. Convert list (ArrayList) of String to stream");
        Stream<String> streamOfString = listOfStrings.stream();

        System.out.println("3. Display Stream of String");
        streamOfString.forEach(System.out::println);
    }
}
