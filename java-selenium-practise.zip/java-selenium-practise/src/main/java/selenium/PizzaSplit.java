package selenium;

import java.util.Scanner;

public class PizzaSplit {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int noOfFriends = sc.nextInt();
        int noOfPieces = sc.nextInt();

         int noOfPizza = 1;
         int totalNoOfPieces = noOfPizza * noOfPieces;
         while (totalNoOfPieces%noOfFriends !=0){
             noOfPizza++;
             totalNoOfPieces = noOfPizza*noOfPieces;
         }
         System.out.println(noOfPizza);


    }
}
