package selenium;

import org.bouncycastle.oer.Switch;

import java.util.Scanner;

public class TopicDecisionMethods {
    public static void main(String[] args) {
//        //Qn.What is Decision-making statement
//        // Statements allows you to make a decision, based upon the result of a condition.
//        //if
//        //Syntax: if(condition){ //statements }
//        int i = 10;
//        if (i < 0) {
//            System.out.println("The i value is negative");
//        }
//
//        //if-else
//        //Syntax: if(condition){ //statements } else { //statements }
//        int j = 10;
//        if (j < 0) {
//            System.out.println("The j value is negative");
//        } else {
//            System.out.println("The j value is positive");
//        }
//
//        //nested-if
//        Scanner sc = new Scanner(System.in);
//        System.out.println("What is your exam status");
//        String examStatus = sc.nextLine();
//        //String examStatus = "pass";
//        if (examStatus.equals("pass")) {
//            System.out.println("Please wait for further rounds");
//
//
//            String round1 = sc.nextLine();
//            if (round1.equals("pass")) {
//                System.out.println("Please wait for round2");
//
//                String round2 = sc.nextLine();
//                if (round2.equals("pass")) {
//                    System.out.println("Please wait for HR round");
//                } else {
//                    System.out.println("you go to home");
//                }
//            } else {
//                System.out.println("you go to home");
//            }
//        }
//        else
//        {
//        System.out.println("you got to home");
//        }
//

        //HomeWork if and if else
        //1qn: Verify the given number is even or odd.
//        Scanner sc = new Scanner(System.in);
//        System.out.println("give any number");
//        int value1 = sc.nextInt();
//        if( value1 % 2 == 0){
//            System.out.println("The given value is even number");
//        }
//        else {
//            System.out.println("The given value is odd number");
//        }
        //2qn: Print the student result based on the grading system
//        Scanner sc = new Scanner(System.in);
//        System.out.println("may i know about marks");
//        int marks = sc.nextInt();
//        if (marks >= 85){
//            System.out.println("Student secured first class");
//        }
//        else if(marks >=70 && marks < 85){
//            System.out.println("Student secured second class");
//        }
//        else if( marks >35 && marks <70){
//            System.out.println("Student secured third class");
//        }
//        else if ( marks == 35){
//            System.out.println("Student is passed");
//        }
//        else {
//            System.out.println("Student is failed");
//        }

        //3qn: print the statements based on day name
        //Monday to Friday-> Uff, it's a weekday
        //Saturday&Sunday -> yeah, it's weekend
//        Scanner sc = new Scanner(System.in);
//        System.out.println("please enter your day");
//        String day = sc.nextLine();
//        if(day.equals("saturday") || day.equals("sunday")){
//            System.out.println("yeah, it's weekend");
//        }
//        else{
//            System.out.println("Uff, it's a weekday");
//        }
        //Switch
        //Syntax: switch(key){
        //case value:  //statements
        //break;
        //default: //statements
        //break;
        //}
        //value based condition statements (== condition)
        //multiple outcomes
        //have common outcome
        //don't execute next statements then we use break;
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter your value");
//        switch (sc.nextInt()) {
//            case 1:
//                System.out.println("this the first statement");
//                break;
//            case 2:
//                System.out.println("this is the second statement");
//                break;
//            case 3:
//                System.out.println("this is the third statement");
//                break;
//            default:
//                System.err.println("this is invalid statement");
//                break;
//        }
        //Homework switch
        //1qn: Verify the given number is even or odd.
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Enter you value");
//        int a = scanner.nextInt();
//        switch (a%2) {
//            case 1:
//                System.out.println("this given value is odd number");
//                break;
//            default:
//                System.out.println("the given value is even number");
//                break;
//
//        }
        //2qn : perform arithmetic operation on two numbers (+, -, *, /, %)
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter your first number");
//        int firstNumber = sc.nextInt();
//        System.out.println("Enter your second number");
//        int secondNumber = sc.nextInt();
//        System.out.println("Enter the target operation");
//        String operation = sc.next();
//        int result = performOperation(firstNumber, secondNumber, operation );
//        System.out.println(result);
//    }
//    public static int performOperation(int firstNumber, int secondNumber, String operation){
//            int result = 0;
//            switch (operation) {
//                case "+":
//                    result = firstNumber + secondNumber;
//                    break;
//                case "-":
//                    result = firstNumber - secondNumber;
//                    break;
//                case "*":
//                    result = firstNumber * secondNumber;
//                    break;
//                case "%":
//                    result = firstNumber % secondNumber;
//                    break;
//                case "/":
//                    result = firstNumber / secondNumber;
//                    break;
//                default:
//                    System.out.println("Invalid operation");
//                    break;
//            }
//            return result;

        Scanner sc = new Scanner(System.in);
        System.out.println("enter your day");
        String day = sc.nextLine();
        switch (day){
            case  "Sunday", "Saturday":
                System.out.println("yeah, it's is weekend");
                break;
            case "Monday", "Tuesday", "Wednesday", "Thursday", "Friday":
                System.out.println("Uff, it's a weekday");
                break;
            default :
                System.err.println("this not a day name");
        }

    }

}
