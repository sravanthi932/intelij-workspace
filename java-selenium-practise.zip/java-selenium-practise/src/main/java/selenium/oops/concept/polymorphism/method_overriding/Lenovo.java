package selenium.oops.concept.polymorphism.method_overriding;

import selenium.abstractclass_topic.Lenevo;

public class Lenovo extends SuperAC {

    public void paste() {
        System.out.println("lenovo paste code");
    }

    @Override//used override the method of the parent class SuperAC
    public void copy() {
        System.out.println("lenovo updated code");
    }

    public static void main(String[] args) {
    }
}
