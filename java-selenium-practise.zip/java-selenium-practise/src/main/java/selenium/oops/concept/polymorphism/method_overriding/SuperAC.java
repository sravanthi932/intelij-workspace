package selenium.oops.concept.polymorphism.method_overriding;

public abstract class SuperAC implements Laptop{

    public void copy() {
        System.out.println("copy code");
    }

    public void cut() {
        System.out.println("cut code");
    }
}
