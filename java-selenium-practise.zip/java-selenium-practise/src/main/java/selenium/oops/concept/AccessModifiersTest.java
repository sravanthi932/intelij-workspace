package selenium.oops.concept;

import selenium.access_modifiers.Student;

public class AccessModifiersTest {
    public static void main(String[] args) {
//        Student student = new Student();
//        student.printRollNumber();
//        System.out.println(student.rollNo);
    }
}
