package selenium.oops.concept.polymorphism.method_overriding;

public interface Laptop {
    public void copy();

    public void cut();

    public void paste();

}
