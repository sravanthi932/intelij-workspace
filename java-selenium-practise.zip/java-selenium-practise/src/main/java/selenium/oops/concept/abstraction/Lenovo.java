package selenium.oops.concept.abstraction;

public class Lenovo extends SuperAc{

    public void cut() {
        System.out.println("cut code");
    }

    public void keyBoard() {
         System.out.println("keyBoard code");
    }
    @Override
    public void paste(){
        System.out.println("overriding the paste method of SuperAC");
    }
}
