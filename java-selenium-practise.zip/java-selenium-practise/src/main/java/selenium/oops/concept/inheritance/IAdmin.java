package selenium.oops.concept.inheritance;

public interface IAdmin extends IDeveloper,IGuest{
    public void manage();
}
