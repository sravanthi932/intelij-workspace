package selenium.oops.concept.inheritance;

public class Guest {
    public void read(){
        System.out.println("read code updated");
    }
}
