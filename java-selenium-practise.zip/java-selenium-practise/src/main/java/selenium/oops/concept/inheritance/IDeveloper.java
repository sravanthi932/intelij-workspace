package selenium.oops.concept.inheritance;

public interface IDeveloper extends IGuest {
    public void write();
}
