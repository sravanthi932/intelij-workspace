package selenium.oops.concept.inheritance;

public interface IGuest {
    public void read();
}
