package selenium.oops.concept.abstraction;

import selenium.abstractclass_topic.Lenevo;

public class Users {
    public static void main(String[] args) {
        //using abstract class we achieve abstraction
        SuperAc lenovo = new Lenovo();
        lenovo.copy();
        lenovo.cut();
        lenovo.paste();

        //using interface we achieve 100% abstraction
        Laptop le = new Lenovo();
        le.keyBoard();
        le.paste();
        Lenevo l = new Lenevo();
        l.paste();

    }
}
