package selenium.oops.concept.encapsulation;

public class Teacher {
    public static void main(String[] args) {
        Student s = new Student(101);
        s.setAttended(true);
        s.isAttended();
    }
}
