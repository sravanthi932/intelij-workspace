package selenium.oops.concept.inheritance;

public class Developer extends Guest{
    public void write(){
        System.out.println("write the code");
    }
}
