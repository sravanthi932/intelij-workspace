package selenium.oops.concept.polymorphism;

public class Method_Overloading {
    public void add(int a, int b ){
        System.out.println("input:" );
    }
    public void add(int a, int b, int c){
        System.out.println("input:");
    }

    public static void main(String[] args) {
        Method_Overloading mo = new Method_Overloading();
        mo.add(2, 8);
        mo.add(4, 7, 9);
        //this is the best example for method overloading
        System.out.println();
    }
}
