package selenium.oops.concept.abstraction;

public interface Laptop {

    public void copy();

    public void paste();

    public void cut();

    public void keyBoard();

}
