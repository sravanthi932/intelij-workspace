package selenium.oops.concept.inheritance;

public class User implements IAdmin{
    public static void main(String[] args){
//        Admin admin = new Admin();
//        admin.read();
//        admin.write();
//        admin.manage();
    }

    @Override
    public void manage() {
        System.out.println("manage the code");
    }

    @Override
    public void write() {
        System.out.println("write the code");
    }

    @Override
    public void read() {
         System.out.println("read the code");
    }
}
