package selenium.oops.concept;

import selenium.access_modifiers.Student;

public class ProtectedAccessModifierTest extends Student {
    public static void main(String[] args) {
        new ProtectedAccessModifierTest().test();
    }
    public void test(){
        System.out.println(rollNo);
        printRollNumber();
    }
}
