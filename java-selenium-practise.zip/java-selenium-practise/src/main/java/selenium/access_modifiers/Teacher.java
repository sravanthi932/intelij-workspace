package selenium.access_modifiers;

public class Teacher extends Student{
    @Override
    public void cut(){
        System.out.println("overriding the cut code");
    }
    public static void main(String[] args) {
        Student s= new Student();
        s.printRollNumber();
        System.out.println(s.rollNo);


        Teacher t= new Teacher();
        t.cut();
    }
}
