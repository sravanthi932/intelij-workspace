package selenium.access_modifiers;

public class Student {
//    public int rollNo = 101;
//    public Student(){
//        rollNo =102;
//    }
//    public void printRollNumber(){
//       System.out.println(rollNo);
//    }
//
//    public static void main(String[] args) {
//        Student s = new Student();
//    }
//    public void abc(){
//        printRollNumber();
//    }

    //private

//private int rollNo = 101;
//    private Student(){
//        rollNo =102;
//    }
//    private void printRollNumber(){
//        System.out.println(rollNo);
//    }
//
//    private static void main(String[] args) {
//        Student s = new Student();
//    }
//    private void abc(){
//        printRollNumber();
//    }


    //default
//     int rollNo = 101;
//    Student(){
//        rollNo =102;
//    }
//     void printRollNumber(){
//        System.out.println(rollNo);
//    }
//
//    public static void main(String[] args) {
//        Student s = new Student();
//    }
//    public void abc(){
//        printRollNumber();
//    }

    //Protected
    protected int rollNo = 101;
    protected Student(){
        rollNo =102;
    }
    protected void printRollNumber(){
        System.out.println(rollNo);
    }

    public static void main(String[] args) {
        Student s = new Student();
    }
    public void abc(){
        printRollNumber();
    }
    public void cut(){
        System.out.println("cut the code");
    }

}
