package selenium.collections.map;



import com.google.common.collect.Multiset;

import java.util.*;

public class MapPractise {
    public static void main(String[] args) {
        List<Integer> l = new ArrayList<>();

        //creation of a map
        Map<Integer, String> mp = new Hashtable<>();

        //Addition of elements into the map
        mp.put(500401, "Rudragudem");
        mp.put(601331, "nallabelly");
        mp.put(566409, "neelojipally");

        //Retrieval of keys from the map
//        Set<Integer> keys = mp.keySet();
//        for (Integer key : keys){
//            System.out.println(key);
//        }
//        System.out.println();
//
//        //Retrieval of values from the map
//        Collection<String> values = mp.values();
//        for (String value : values){
//            System.out.println(value);
//        }
//        System.out.println();
//
//        //Retrieval of values from the map based on a key
//        System.out.println(mp.get(601331));
//        System.out.println();
//
//        for (Integer key : keys){
//            System.out.println(key + "-" + mp.get(key));
//        }
//
//        System.out.println(mp);
//
//        //Deletion of element from the map
//        mp.remove(566409);
//
//        System.out.println(mp);
//
//        //Verification of key in a map
//        System.out.println(mp.containsKey(566409));
//        System.out.println(mp.containsKey(601331));
//
//        //Verification of value in a map
//        System.out.println(mp.containsValue("nallabelly"));
//        System.out.println(mp.containsValue("nalabelly"));
//        System.out.println(mp);
//        mp.replace(601331, "warangal");
//        System.out.println(mp);
//        mp.clear();
//        System.out.println(mp);

        //EntrySet
        Set<Map.Entry<Integer, String>> entries = mp.entrySet();
        for (Map.Entry<Integer, String> entry :entries){
            Integer key = entry.getKey();
            String value = entry.getValue();
            System.out.println(key + "..." + value);
        }
    }
}
