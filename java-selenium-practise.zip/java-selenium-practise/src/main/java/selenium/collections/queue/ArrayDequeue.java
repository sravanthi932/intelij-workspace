package selenium.collections.queue;

import java.util.ArrayDeque;
import java.util.Queue;

public class ArrayDequeue {
    public static void main(String[] args) {
        ArrayDeque<String> ad = new ArrayDeque<>();
        //Addition of elements
        ad.add("banana");
        ad.offerFirst("grapes");//used for adding the elements
        ad.offer("apple");
        ad.addFirst("kiwi");
        ad.add("dragon");
        ad.offerLast("guva");
        System.out.println(ad);


        //Retrieval
        System.out.println(ad.peekFirst());
        System.out.println(ad.peek());
        System.out.println(ad);


        //Deletion
        System.out.println(ad.pollFirst());
        System.out.println(ad);
        System.out.println(ad.poll());
        System.out.println(ad);
        System.out.println(ad.remove());
        System.out.println(ad);
//        pq.clear();
//        System.out.println(pq);
//        System.out.println(pq.poll());
//        System.out.println(pq.remove()); //no such element exception

        //Verification
        System.out.println(ad.contains("banana"));
        System.out.println(ad.contains("betroot"));
    }
}
