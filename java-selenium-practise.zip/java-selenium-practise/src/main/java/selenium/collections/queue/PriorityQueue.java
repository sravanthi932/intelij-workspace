package selenium.collections.queue;

import java.util.Comparator;
import java.util.Queue;

public class PriorityQueue {
    public static void main(String[] args) {
        //methods
        //Addition : offer, add
        //retrieval : peek
        //deletion : poll, remove

        Queue<Integer> pq = new java.util.PriorityQueue<>();

        //Addition of elements
        pq.add(8);
        pq.offer(5);//used for adding the elements
        pq.offer(9);
        pq.add(10);
        pq.add(3);
        pq.offer(1);
        System.out.println(pq);

        //Retrieval
        System.out.println(pq.peek());
        System.out.println(pq.peek());
        System.out.println(pq);

        //Deletion
        System.out.println(pq.poll());
        System.out.println(pq);
        System.out.println(pq.poll());
        System.out.println(pq);
        System.out.println(pq.remove());
        System.out.println(pq);
//        pq.clear();
//        System.out.println(pq);
//        System.out.println(pq.poll());
//        System.out.println(pq.remove()); //no such element exception

        //Verification
        System.out.println(pq.contains(5));
        System.out.println(pq.contains(23));

        //Retrieval of elements
        while (!pq.isEmpty()){
            System.out.print(pq.poll());
        }
        System.out.println();

        Queue<Integer> pq1 = new java.util.PriorityQueue<>(Comparator.reverseOrder());
        pq1.add(8);
        pq1.offer(5);//used for adding the elements
        pq1.offer(9);
        pq1.add(10);
        pq1.add(3);
        pq1.offer(1);
        System.out.println(pq1);
    }
}
