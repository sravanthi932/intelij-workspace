package selenium.collections.List;

import java.util.*;

public class ArrayListPractise {
    public static void main(String[] args) {
        Integer[] arr = new Integer[]{1,2,3,4,5};
        ArrayList<Integer> al = new ArrayList<>(200);
        //addition
        al.add(5);
        al.add(null);
        al.add(8);
        al.add(5);
        al.add(3);
        System.out.println(al);
        //Retrievel
        System.out.println(al.get(2));
        //Deletion
        System.out.println(al.remove(null));
        //Verification
        System.out.println(al.contains(3));
        //updation
        al.set(1, 9);
        System.out.println(al);
        System.out.println(al.size());

    }
}
