package selenium.collections.List;

import java.util.Stack;

public class StackPractise {
    public static void main(String[] args) {
        /*
        LIFO - Last In First Out - stack
        FIFO - First In First Out - Queue

        Stack is a class which implements the List interface and extends the Vector class and which follows the LIFO principle.
        Vector we can give the initial size as 10 , 20 like that in parameterised constructor but in stack we can't give any size.
         */
        Stack<String> books = new Stack<>();
        //Addition
        books.add("White");
        books.add("Red");
        books.add(0,"Black");
        //Retrieve
        System.out.println(books.get(0));
        System.out.println(books);
        //Deletion
        books.remove("White");//object
        System.out.println(books);
        books.remove(0);//using index
        System.out.println(books);
        //verification
        books.contains("Red");
        //Updation
        books.setSize(5);
        books.set(1,"White");
        System.out.println(books);

        //Special methods available in stack
        /*
        1.Push
        2.Pop //deleting
        3.Peek //seeing
        4.Search
         */

        Stack<String> colours = new Stack<>();
        colours.push("Red");
        colours.push("White");
        colours.push("black");
        System.out.println(colours.peek());
        System.out.println(colours.pop());
        System.out.println(colours.search("Red"));
        System.out.println(colours.indexOf("Red"));
        System.out.println(colours);
    }
}
