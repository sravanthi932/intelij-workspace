package selenium.collections.List;

import java.util.ArrayList;
import java.util.LinkedList;

public class LinkedListPractise {
    public static void main(String[] args) {
        // we can traverse to Right and Left both
        ArrayList<String> al = new ArrayList<>();
        al.add("n1");
        al.add("n2");

        LinkedList<String> ll = new LinkedList<>();
        ll.add("S1");
        ll.add("s2");
        ll.add("s3");
        ll.add("S4");
        ll.add("s5");
        ll.add("s6");
        ll.addAll(al);
        ll.add(0,"S0");
        System.out.println(ll);
        ll.remove(1);
        System.out.println(ll);
        ll.remove();
        System.out.println(ll);
        ll.remove("n2");
        System.out.println(ll);
        System.out.println(ll.getFirst());
        System.out.println(ll.getLast());
        ll.contains("n1");
        ll.set(5,"kanna");
        System.out.println(ll);
    }
}
