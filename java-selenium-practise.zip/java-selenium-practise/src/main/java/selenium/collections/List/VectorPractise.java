package selenium.collections.List;

import java.util.*;

public class VectorPractise {
    public static void main(String[] args) {

        Vector v1 = new Vector();
        v1.add("Naveen");
        v1.add("Sravanthi");
        v1.add("Hethvik");
        v1.add(0,"konakati");
        v1.add("v1");
        v1.add("v2");
        v1.add("v3");
        v1.add("v4");
        v1.add("v5");
        v1.add("v6");
        v1.add("v7");
        v1.add("v8");
        v1.add("v9");

        Vector v2 = new Vector();
        v2.add("Anumula");
        v2.add("Lingareddy");
        v2.add("Rama");
        v2.add("sravan");


        Vector v3 = new Vector();
        v3.add("Singireddy");
        v3.add("Anil");
        v3.add("Lavanya");
        v3.add("Sagarika");
        v3.add("Karthikeya");



        System.out.println(v1);
        //Addition
        System.out.println(v1.addAll(v2));
        System.out.println(v1);
        System.out.println(v1.addAll(v3));
        System.out.println(v1);
        System.out.println(v1.capacity());
        System.out.println(v1.size());
        //Retrieve
        System.out.println(v1.get(2));
        //Deletion
        System.out.println(v3.remove(0));
        System.out.println(v3);
        System.out.println(v1.remove("v1"));
        System.out.println(v1);
        System.out.println(v1.removeAll(v2));
        System.out.println(v1);
        v3.clear();
        System.out.println(v3);
        //verification
        System.out.println(v1.contains("Hethvik"));
        System.out.println(v1.containsAll(v2));
        //updation
        v1.set(0,"konukati");
        System.out.println(v1);
        System.out.println(v1.get(0));
        System.out.println(v1.indexOf("Hethvik"));
        System.out.println(v1.lastIndexOf(v1));
        System.out.println(v1.firstElement());
        System.out.println(v1.lastElement());

        Vector v4 = new Vector(200);
        v4.add("ammu");
        System.out.println(v4);
        System.out.println(v4.size());
        System.out.println(v4.capacity());

        Object[] arr = new Object[]{1, 2 , 3 , 4 , 5} ;
        Vector v5 = new Vector(Arrays.asList(arr));
        System.out.println(v5);
        System.out.println(v5.size());
        System.out.println(v5.capacity());

        //Generics
        Vector<Integer> v6 = new Vector<>();
        //v5.add("sravs");//throwing error because we mentioned data type as Integer so it doesn't take string.
        v6.add(12);
        v6.add(5);
        v6.add(null);
        v6.add(null);
        v6.add(5);
        v6.add(5);
        v6.add(null);

        System.out.println(v6);
        System.out.println(v6.size());
        System.out.println(v6.capacity());
    }

}
