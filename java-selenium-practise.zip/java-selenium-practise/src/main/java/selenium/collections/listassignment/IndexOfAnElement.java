package selenium.collections.listassignment;

import java.util.ArrayList;
import java.util.Arrays;

public class IndexOfAnElement {
    public static void main(String[] args) {
        ArrayList<Integer> al = new ArrayList<>(Arrays.asList(1, 8, 0, 5, 1, 6));
        Integer targetElement = 0;

        for (int i=0; i<al.size(); i++){
            if (targetElement == al.get(i)){
                System.out.println(i+1);
                break;
            }
        }
        System.out.println(al.indexOf(targetElement));
    }
}
