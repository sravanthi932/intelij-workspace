package selenium.collections.listassignment;

import java.util.ArrayList;
import java.util.Arrays;

public class CommonElements {
    public static void main(String[] args) {
        ArrayList<Integer> list1 = new ArrayList<>(Arrays.asList
                (4, 5, 8, 9)
        );
        ArrayList<Integer> list2 = new ArrayList<>(Arrays.asList
                (1, 8, 0, 5, 1, 6)
        );
        ArrayList<Integer> list3 = new ArrayList<>();

        for (Integer element : list1) {
            for (Integer element1 : list2) {
                if(element == element1)
                {
                    list3.add(element);
                    break;
                }
            }
        }
           System.out.println(list3);

    }
}
