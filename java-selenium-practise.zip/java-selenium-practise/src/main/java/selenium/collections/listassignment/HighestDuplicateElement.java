package selenium.collections.listassignment;

import java.util.ArrayList;
import java.util.Arrays;

public class HighestDuplicateElement {
    public static void main(String[] args) {
        ArrayList<Integer> al = new ArrayList<>(Arrays.asList(
                4, 1, 9, 4, 8, 0, 5, 8, 1, 8, 6
        ));

        ArrayList<Integer> uniqueElements = new ArrayList<Integer>();
        for( Integer element : al) {
            if (!uniqueElements.contains(element))
                uniqueElements.add(element);
        }

        //      HashSet<String> uniqueElements = new HashSet<>(al);
        System.out.println(uniqueElements);

        int highestCount = 0;
        int highestDuplicatedNumber = al.get(0);
        for (Integer uniqueElement: uniqueElements){
            int repeatedCount = 0;

            for (Integer element : al){
                if (uniqueElement.equals(element))
                    repeatedCount++;
            }
            if(repeatedCount > 1){
                if(highestCount < repeatedCount){
                    highestCount = repeatedCount;
                    highestDuplicatedNumber = uniqueElement;
                }
            }
        }
        System.out.println(highestDuplicatedNumber );
    }
}
