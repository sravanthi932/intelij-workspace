package selenium.collections.listassignment;

import java.util.Vector;

public class SplitTheList {
    public static void main(String[] args) {
        Vector<Integer> v = new Vector<>();
        v.add(4);
        v.add(9);
        v.add(8);
        v.add(5);
        v.add(0);
        v.add(10);

         Vector<Integer> list1 = new Vector<>();
         Vector<Integer> list2 = new Vector<>();
         for (int i=0;i< v.size(); i++){
             if(i<v.size()/2){
                 list1.add(v.get(i));
             }
             else {
                 list2.add(v.get(i));
             }
         }
         System.out.println(list1);
         System.out.println(list2);
    }
}
