package selenium.collections.listassignment;

import java.util.ArrayList;
import java.util.Arrays;

public class LIstToArray {
    public static void main(String[] args) {
        ArrayList<Integer> al = new ArrayList<>(Arrays.asList(4, 9, 8, 5, 0, 10));
        Integer[] arr = al.toArray(new Integer[al.size()]);
        System.out.println(Arrays.toString(arr));
    }
}
