package selenium.collections.listassignment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class RepetitionCount {
    public static void main(String[] args) {
        ArrayList<String> al = new ArrayList<>(Arrays.asList(
                "baby", "ball", "soap", "baby", "shampoo",
                "chalk", "soap", "makeup", "baby", "lotion"
        ));

        ArrayList<String> uniqueElements = new ArrayList<String>();
        for( String element : al) {
            if (!uniqueElements.contains(element))
                uniqueElements.add(element);
        }

  //      HashSet<String> uniqueElements = new HashSet<>(al);
        System.out.println(uniqueElements);
       //
        for (String uniqueElement: uniqueElements){
            int repeatedCount = 0;

            for (String element : al){
                if (uniqueElement.equals(element))
                    repeatedCount++;
            }
            if(repeatedCount > 1){
                System.out.println(uniqueElement + "-" + repeatedCount );
            }
        }
    }
}
