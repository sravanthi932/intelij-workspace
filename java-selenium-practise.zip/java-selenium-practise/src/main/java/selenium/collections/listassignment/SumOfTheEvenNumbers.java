package selenium.collections.listassignment;

import java.util.LinkedList;
import java.util.Scanner;

public class SumOfTheEvenNumbers {
    public static void main(String[] args) {
//        LinkedList<Integer> ll = new LinkedList<>();
//        ll.add(4);
//        ll.add(5);
//        ll.add(0);
//        ll.add(9);
//        ll.add(8);
//        ll.add(10);
//
//        int sum = 0;
//        for (int i=0; i< ll.size(); i++){
//            if(ll.get(i)%2==0){
//                sum += ll.get(i);
//            }
//        }
//         System.out.println(sum);

        Scanner sc = new Scanner(System.in);
        System.out.println("How many elements you want to store in the list");
        int listSize = sc.nextInt();
        LinkedList<Integer> ll1 = new LinkedList<>();
        System.out.println("enter the elements");

        int sum1=0;
        for (int i=0; i<listSize;i++){
            ll1.add(sc.nextInt());
            if(ll1.get(i)%2==0){
                sum1 += ll1.get(i);
            }
        }
        System.out.println(sum1);

    }
}
