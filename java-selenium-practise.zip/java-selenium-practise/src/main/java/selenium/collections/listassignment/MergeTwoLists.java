package selenium.collections.listassignment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class MergeTwoLists {
    public static void main(String[] args) {
        ArrayList<Integer> list1 = new ArrayList<>();
        list1.add(4);
        list1.add(9);
        list1.add(8);
        System.out.println(list1);

        LinkedList<Integer> list2 = new LinkedList<>();
        list2.add(5);
        list2.add(0);
        list2.add(10);
        System.out.println(list2);

        LinkedList<Integer> list3 = new LinkedList<>(list1);
        list3.addAll(list2);
        System.out.println(list3);

    }
}
