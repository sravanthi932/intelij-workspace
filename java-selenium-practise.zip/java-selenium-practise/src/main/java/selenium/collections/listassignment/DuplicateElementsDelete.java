package selenium.collections.listassignment;

import selenium.topic_looping_statements.TopicWhile;

import java.util.ArrayList;
import java.util.Arrays;

public class DuplicateElementsDelete {
    public static void main(String[] args) {
        ArrayList<Integer> al = new ArrayList<>
                (Arrays.asList(
                        4, 1, 9, 4, 8, 0, 5, 1, 8, 6
                ));
        ArrayList<Integer> uniqueElements = new ArrayList<Integer>();
        for (Integer element : al) {
            if (!uniqueElements.contains(element))
                uniqueElements.add(element);
        }
        for (Integer uniqueElement : uniqueElements) {
            int repeatedCount = 0;

//            for (Integer element : al) {
//                if (uniqueElement.equals(element))
//                    repeatedCount++;
//            }
//            if (repeatedCount > 1) {
//                while (al.contains(uniqueElement))
//                    al.remove(uniqueElement);
//            }
            if(al.indexOf(uniqueElement) != al.lastIndexOf(uniqueElement)){
                while (al.contains(uniqueElement))
                    al.remove(uniqueElement);
            }
        }
        System.out.println(al);
    }
}
