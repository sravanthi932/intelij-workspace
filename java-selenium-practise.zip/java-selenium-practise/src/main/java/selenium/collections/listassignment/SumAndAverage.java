package selenium.collections.listassignment;

import java.util.ArrayList;
import java.util.Scanner;

public class SumAndAverage {
    //WAP to print the Sum and average of the elements present in the list.
    public static void main(String[] args) {
        ArrayList<Integer> al = new ArrayList<>();
        al.add(4);
        al.add(5);
        al.add(0);
        al.add(9);
        al.add(8);
        al.add(10);

        int sum = 0;
        int avg = 0;
        for (int i=0; i< al.size(); i++) {
           sum += al.get(i);
        }
        System.out.println("Sum"+ sum);

        System.out.println("avg"+ sum/al.size());

        //2nd way using scanner
        Scanner sc = new Scanner(System.in);
        System.out.println("How many elements you want to store in the list");
        int listSize = sc.nextInt();
        ArrayList<Integer> al1 = new ArrayList<>();
        System.out.println("enter the elements");

        for (int i=0; i<listSize; i++){
            al1.add(sc.nextInt());
        }
        int Sum = 0;
        for (Integer element : al1){
            Sum += element;
        }
        System.out.println(al1);
        System.out.println("Sum " +Sum);
        System.out.println("abg " +Sum/al1.size());
    }

}
