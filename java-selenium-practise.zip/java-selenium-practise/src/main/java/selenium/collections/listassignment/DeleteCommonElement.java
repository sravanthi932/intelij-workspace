package selenium.collections.listassignment;

import java.util.ArrayList;
import java.util.Arrays;

public class DeleteCommonElement {
    public static void main(String[] args) {
        ArrayList<Integer> list1 = new ArrayList<>(Arrays.asList
                (4, 8, 9)
        );
        ArrayList<Integer> list2 = new ArrayList<>(Arrays.asList
                (4, 1, 9, 4, 8, 0, 5, 1, 8, 6)
        );
       // ArrayList<Integer> list3 = new ArrayList<>();

        for (Integer element : list1) {
            while (list2.contains(element))
                list2.remove(element);
        }
        System.out.println(list2);

    }
}
