package selenium.collections.listassignment;

import java.util.ArrayList;

public class PrimeNumber {
    public static void main(String[] args) {
        int firstNumber = 0;
        int lastNumber = 50;

        ArrayList<Integer> primeNumber = new ArrayList<>();

        int number = firstNumber;
        while (number <= lastNumber) {
            boolean isPrime = true;

            if (number != 0 && number != 1) {
                int i = 2;
                while (i < number) {
                    if (number % i == 0) {
                        isPrime = false;
                        break;
                    }
                    i++;
                }
            } else isPrime = false;
            if (isPrime)
                primeNumber.add(number);
            number++;
        }
        System.out.println(primeNumber);
    }
}
