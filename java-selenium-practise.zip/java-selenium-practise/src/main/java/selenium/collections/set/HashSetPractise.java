package selenium.collections.set;

import java.util.HashSet;

public class HashSetPractise {
    public static void main(String[] args) {
        //HashSet -> HashMap -> Array of nodes(key, value)
        //new Object(); dummy object
        HashSet<Integer> hs = new HashSet<>();
        hs.add(10);
        hs.add(3);
        hs.add(9);
        //doesn't allow the duplicates and it doesn't maintain any order
        hs.add(9);
        hs.add(6);
        hs.add(4);
        hs.add(2);
        hs.add(null);

        System.out.println(hs.remove(3));
        System.out.println(hs.remove(0));
        System.out.println(hs.contains(4));
        for ( Integer element : hs) {
            System.out.println(element);
        }
          System.out.println(hs);
    }
}
