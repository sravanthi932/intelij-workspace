package selenium.collections.set;

import java.util.LinkedHashSet;

public class LinkedHashSetPractise {
    public static void main(String[] args) {
        //LinkedHashSet -> LinkedHashMap -> Link of nodes(key, value)
        //new Object(); dummy object
        LinkedHashSet<Integer> lhs = new LinkedHashSet<>();
        lhs.add(1);
        lhs.add(6);
        lhs.add(9);
        lhs.add(5);
        lhs.add(4);
        //doesn't allow the duplicates and it maintains the insertion order.
        lhs.add(4);
        lhs.add(8);
        lhs.add(null);


        System.out.println(lhs);

        System.out.println(lhs.remove(2));
        System.out.println(lhs.remove(6));
        System.out.println(lhs.contains(8));
        System.out.println(lhs.contains(7));

        for ( Integer element : lhs) {
            System.out.println(element);
        }

        lhs.clear();
    }
}
