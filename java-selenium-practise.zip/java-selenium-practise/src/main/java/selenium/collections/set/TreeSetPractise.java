package selenium.collections.set;

import java.util.TreeSet;

public class TreeSetPractise {
    public static void main(String[] args) {
        //TreeSet -> TreeMap -> binary tree
        //new Object(); dummy object
        //it maintains the sorted order(Ascending)
        TreeSet<Integer> ts = new TreeSet<>();
        ts.add(7);
        ts.add(0);
        ts.add(8);
        ts.add(2);
        ts.add(4);
        //doesn't allow the duplicates
        ts.add(0);
        //doesn't allow the null values
       // ts.add(null);
        System.out.println(ts);
        System.out.println(ts.descendingSet());
        System.out.println(ts.pollLast());
        System.out.println(ts.pollFirst());
        System.out.println(ts.first());
        System.out.println(ts.last());
       System.out.println(ts);
    }
}
