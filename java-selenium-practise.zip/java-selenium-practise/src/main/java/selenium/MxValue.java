package selenium;

import java.util.Scanner;

public class MxValue {
    public static void main(String[] args) {
        System.out.println(max());
    }
    public static int max(){
        Scanner sc = new Scanner(System.in);
        int maxValue = sc.nextInt();
        if(maxValue ==0){
            return 0;
        }
        while(true) {
            int userNumber = sc.nextInt();
            if (userNumber == 0) {
               break;
            }
            if(userNumber > maxValue) {
                maxValue = userNumber;
            }
        }
        return maxValue;
    }
}
