package selenium.topic_arrays;

import java.util.Arrays;
import java.util.Scanner;

public class Single_Dimentional_Array {
    // while using primitive data types so,java is not a 100% OOP.
    //int a = 10;
    //we didn't create object.
    //primitive data types didn't need creation of object(byte,long,int,float,string,char,double,short)
    //non-primitive data types are class, Arrays and collections.
    //Array is a container object which stores the fixed number of values of a single type.
    //Single-Dimensional Array
    //Multi-Dimensional Array
        //Two-Dimensional Array
        //Jagged Array
    public static void main(String[] args) {
//        int i[] =new int[5];
//        i[0] = 2;
//        i[1] = 3;
//        i[2] = 4;
//        i[3] = 5;
//        i[4] = 6;
//        System.out.println(i[4]);
//        for(int j=0; j<i.length; j++){
//            System.out.println(i[j]);
//        }
//        int k = 0;
//        while(k<i.length){
//            System.out.println(i);
//            k++;
//        }
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter the array size");
//        int arrSize = sc.nextInt();
//        int arr[] = new int[arrSize];
//        System.out.println("enter the values in an array");
//        for (int i=0; i<arrSize; i++){
//            arr[i]=sc.nextInt();
//        }
//        System.out.println(Arrays.toString(arr));
        //Homework
        //1qn.Print the sum of the integers in an array
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter the array size");
//        int arrSize = sc.nextInt();
//        int arr[] = new int[arrSize];
//        System.out.println("enter the values in an array");
//        for (int i=0; i<arrSize; i++){
//            arr[i]=sc.nextInt();
//        }
//        System.out.println("input:" +Arrays.toString(arr));
//        int sum =0;
//        for (int i=0; i<arr.length;i++){
//            sum += arr[i];
//        }
//          System.out.println("output:" +sum);

        //2qn.Print the avg of the integers in an array.

//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter the array size");
//        int arrSize = sc.nextInt();
//
//        int arr[] = new int[arrSize];
//        System.out.println("enter the values in an array");
//        for (int i=0; i<arrSize; i++){
//            arr[i]=sc.nextInt();
//        }
//
//        System.out.println(Arrays.toString(arr));
//        int sum =0;
//        int avg = 0;
//        for(int i=0; i<arr.length; i++){
//            sum += arr[i];
//            avg = sum / arr.length;
//        }
//        System.out.println("output:" +sum);
//        System.out.println("output:" +avg);

        //3qn.Merge two arrays and print the output in the console.
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter the arr1 Size");
//        int arr1Size = sc.nextInt();
//        String arr1[] = new String[arr1Size];
//        System.out.println("enter the values in array1");
//        for (int i=0;i<arr1Size;i++){
//            arr1[i] = sc.next();
//        }
//        System.out.println("enter arr2 Size");
//        int arr2Size = sc.nextInt();
//        String arr2[] = new String[arr2Size];
//        System.out.println("enter the vales in");
//        for (int i=0;i<arr2Size;i++){
//            arr2[i] = sc.next();
//        }
//        System.out.println(Arrays.toString(arr1));
//        System.out.println(Arrays.toString(arr2));
//        String arr3[] = new String[arr1.length + arr2.length];
//        for (int i=0;i<arr1.length;i++){
//            arr3[i] = arr1[i];
//        }
//        for (int i=0;i<arr2.length;i++){
//            arr3[i+arr1.length] = arr2[i];
//        }
//        System.out.println(Arrays.toString(arr3));


        //4qn.Find the max number from array and print it with along its index.
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter the array size");
//        int arrSize = sc.nextInt();
//        int arr[] = new int[arrSize];
//        System.out.println("enter the values in an array");
//        for (int i=0;i<arrSize;i++){
//            arr[i] = sc.nextInt();
//        }
//        System.out.println(Arrays.toString(arr));
//        int largestNumber = arr[0];
//        int largestNumberIndex = 0;
//        for (int i=0; i<arr.length; i++){
//        if (largestNumber < arr[i]){
//            largestNumber = arr[i];
//            largestNumberIndex = i;
//        }
//        }
//        System.out.println("output:" +largestNumber);
//        System.out.println("output:" +largestNumberIndex);


        //5qn.Find the min length word from an array and print it along with its index.
//        Scanner sc = new Scanner(System.in);
//        System.out.println("give the array size");
//        int arrSize = sc.nextInt();
//        String arr[] = new String[arrSize];
//        System.out.println("enter the values in an array");
//        for (int i=0;i<arrSize;i++){
//            arr[i] =sc.next();
//        }
//        String smallWord = arr[0];
//        int smallWordIndex = 0;
//        for (int i=0;i<arr.length;i++) {
//            if (smallWord.length()>arr[i].length()){
//                smallWord = arr[i];
//                smallWordIndex = i;
//            }
//        }
//        System.out.println(smallWord);
//        System.out.println(smallWordIndex);

        //6qn.Reverse the array and print in the console.
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the array size");
        int arrSize = sc.nextInt();
        String arr[] = new String[arrSize];
        System.out.println("enter the values in an array");
        for (int i=0;i<arrSize;i++){
            arr[i] = sc.next();
        }
        System.out.println(Arrays.toString(arr));
        String revArray[] = new String[arrSize];
        for (int i=0;i<arr.length;i++){
            revArray[arr.length-i-1] = arr[i];
        }
        System.out.println(Arrays.toString(revArray));
    }

}
