package selenium.topic_arrays;

import java.util.Arrays;
import java.util.Scanner;

public class Jagged_Array_practice {
    //differential in column size it is not same in all rows.
    public static void main(String[] args) {
//        int arr[][] = new int[3][];
//        arr[0] = new int[]{1,2};
//        arr[1] = new int[]{3,4,5,6,7};
//        arr[2] = new int[]{13,64,564};
//        for (int i=0;i<arr.length;i++){
//            for (int j=0;j<arr[i].length;j++){
//                System.out.print(arr[i][j]+" ");
//            }
//            System.out.println("");
//        }
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter number of rows");
//        int rowSize = sc.nextInt();
//        int arr[][] = new int[rowSize][];
//        for (int i=0; i<rowSize; i++) {
//            System.out.println("enter the column size in a row");
//            int colSize = sc.nextInt();
//            arr[i] = new int[colSize];
//            System.out.println("enter the column values for row");
//            for (int j=0;j<colSize; j++){
//                arr[i][j] = sc.nextInt();
//            }
//        }
//        for (int i=0;i< arr.length;i++){
//            System.out.println(Arrays.toString(arr));
//        }
        //Home Work
        //1qn.Print the sum of the elements of a multidimensional array.
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter number of rows");
//        int rowSize = sc.nextInt();
//        int arr[][] = new int[rowSize][];
//        for (int i=0; i<rowSize; i++) {
//            System.out.println("enter the column size in a row");
//            int colSize = sc.nextInt();
//            arr[i] = new int[colSize];
//            System.out.println("enter the column values for row");
//            for (int j=0;j<colSize; j++){
//                arr[i][j] = sc.nextInt();
//            }
//        }
//          for (int i=0;i< arr.length;i++){
//              System.out.println(Arrays.toString(arr[i]));
//          }
//          int sum =0;
//          for ( int i=0; i< arr.length; i++){
//              for (int j=0; j<arr[i].length; j++){
//                  sum += arr[i][j];
//              }
//          }
//          System.out.println(sum);

        //2qn.Add the elements in an array and print it in the console.
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter the number of rows in arr1");
//        int rowSize_arr1 = sc.nextInt();
//        int arr1[][] = new int[rowSize_arr1][];
//        for(int i=0; i<rowSize_arr1;i++){
//            System.out.println("enter the number of columns in a row" +i);
//            int colSize = sc.nextInt();
//            arr1[i] = new int[colSize];
//            System.out.println("enter the column values in a row" +i);
//            for (int j=0; j<colSize; j++){
//                arr1[i][j] = sc.nextInt();
//            }
//        }
//        System.out.println("enter the number of rows in arr2");
//        int rowSize_arr2 = sc.nextInt();
//        int arr2[][] = new int[rowSize_arr2][];
//        for(int i=0; i<rowSize_arr2;i++){
//            System.out.println("enter the number of columns in a row" +i);
//            int colSize = sc.nextInt();
//            arr2[i] = new int[colSize];
//            System.out.println("enter the column values in a row" +i);
//            for (int j=0; j<colSize; j++){
//                arr2[i][j] = sc.nextInt();
//            }
//        }
//        System.out.println("input1:");
//        for (int i=0; i< arr1.length; i++){
//            System.out.println(Arrays.toString(arr1[i]));
//        }
//        System.out.println("input2:");
//        for (int i=0; i< arr2.length; i++){
//            System.out.println(Arrays.toString(arr2[i]));
//        }
//        int arr3[][] = new int[arr1.length][];
//        for (int i=0;i<arr1.length;i++){
//            arr3[i] = new int[arr1[i].length];
//            for (int j=0; j<arr1[i].length; j++){
//                arr3[i][j] = arr1[i][j]+arr2[i][j];
//            }
//        }
//        for ( int i=0;i<arr3.length;i++){
//            System.out.println(Arrays.toString(arr3[i]));
//        }

        //3qn.Create an array with squares of the existing array elements.
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter the row size");
//        int rowSize = sc.nextInt();
//        int[][] arr = new int[rowSize][];
//        for (int i=0; i<rowSize; i++){
//            System.out.println("enter the no of columns in an array" +i);
//            int colSize = sc.nextInt();
//            arr[i] = new int[colSize];
//            System.out.println("enetr the column values in a row" +i);
//            for (int j=0;j<colSize;j++){
//                arr[i][j] = sc.nextInt();
//            }
//        }
//        System.out.println("input:");
//        for (int i=0;i<arr.length;i++){
//            System.out.println(Arrays.toString(arr[i]));
//        }
//        int[][] outPutArray = new int[arr.length][];
//        for(int i=0;i< arr.length;i++){
//            outPutArray[i] = new int[arr[i].length];
//            for (int j=0; j< arr[i].length; j++){
//                outPutArray[i][j] = (int) Math.pow(arr[i][j],2);
//            }
//        }
//        System.out.println("output:");
//        for (int i=0;i<outPutArray.length;i++){
//            System.out.println(Arrays.toString(outPutArray[i]));
//        }

        //4qn print the common elements between two arrays
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter the no of rows in arr1");
//        int rowSize_arr1 = sc.nextInt();
//        int arr1[][] = new int[rowSize_arr1][];
//        for (int i=0;i<rowSize_arr1;i++){
//            System.out.println("enter the no of columns in a row" +i);
//            int colSize_arr1 = sc.nextInt();
//            arr1[i] = new int[colSize_arr1];
//            System.out.println("enter the column values for a row" +i);
//            for (int j=0;j<colSize_arr1;j++){
//                arr1[i][j] = sc.nextInt();
//            }
//        }
//        System.out.println("enter the no of rows in arr2");
//        int rowSize_arr2 = sc.nextInt();
//        int arr2[][] = new int[rowSize_arr2][];
//        for (int i=0;i<rowSize_arr2;i++){
//            System.out.println("enter the no of columns in a row" +i);
//            int colSize_arr2 = sc.nextInt();
//            arr2[i] = new int[colSize_arr2];
//            System.out.println("enter the column values for a row" +i);
//            for (int j=0;j<colSize_arr2;j++){
//                arr2[i][j] = sc.nextInt();
//            }
//        }
//        System.out.println("input:");
//        for (int i=0;i<arr1.length;i++){
//            System.out.println(Arrays.toString(arr1[i]));
//        }
//        System.out.println("input:");
//        for (int i=0;i<arr2.length;i++){
//            System.out.println(Arrays.toString(arr2[i]));
//        }
//        boolean isFound = true;
//        for (int i=0;i<arr1.length;i++){
//            for (int j=0; j<arr1[i].length; j++) {
//                int targetElement = arr1[i][j];
//                for ( int k=0; k<arr2.length; k++){
//                    isFound  = false;
//                    for (int l=0; l<arr2[k].length; l++)
//                        if(targetElement == arr2[k][l]){
//                            System.out.println(targetElement);
//                            isFound = true;
//                            break;
//                        }
//                }
//                if(isFound)
//                    break;
//            }
//        }


        //5qn.create an array based on the mentioned conditions and print it in the console
        //Note: From two arrays validate the value is same in the same indexes then print one otherwise print 0.
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter the number of rows in arr1");
//        int rowSize_arr1 = sc.nextInt();
//        int arr1[][] = new int[rowSize_arr1][];
//        for(int i=0; i<rowSize_arr1;i++){
//            System.out.println("enter the number of columns in a row" +i);
//            int colSize = sc.nextInt();
//            arr1[i] = new int[colSize];
//            System.out.println("enter the column values in a row" +i);
//            for (int j=0; j<colSize; j++){
//                arr1[i][j] = sc.nextInt();
//            }
//        }
//        System.out.println("enter the number of rows in arr2");
//        int rowSize_arr2 = sc.nextInt();
//        int arr2[][] = new int[rowSize_arr2][];
//        for(int i=0; i<rowSize_arr2;i++){
//            System.out.println("enter the number of columns in a row" +i);
//            int colSize = sc.nextInt();
//            arr2[i] = new int[colSize];
//            System.out.println("enter the column values in a row" +i);
//            for (int j=0; j<colSize; j++){
//                arr2[i][j] = sc.nextInt();
//            }
//        }
//        System.out.println("input1:");
//        for (int i=0; i< arr1.length; i++){
//            System.out.println(Arrays.toString(arr1[i]));
//        }
//        System.out.println("input2:");
//        for (int i=0; i< arr2.length; i++){
//            System.out.println(Arrays.toString(arr2[i]));
//        }
//        int arr3[][] = new int[arr1.length][];
//        for (int i=0;i<arr1.length;i++){
//            arr3[i] = new int[arr1[i].length];
//            for (int j=0; j<arr1[i].length; j++){
//                if(arr1[i][j] == arr2[i][j])
//                    arr3[i][j] = 1;
//                    else
//                    arr3[i][j] = 0;
//            }
//        }
//        System.out.println("output:");
//        for ( int i=0;i<arr3.length;i++){
//            System.out.println(Arrays.toString(arr3[i]));
//        }
        //6.qn:Interchange the values in an array by transposing the index values.
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the row size");
        int rowSize = sc.nextInt();
        int[][] arr = new int[rowSize][];
        for (int i=0; i<rowSize; i++){
            System.out.println("enter the no of columns in an array" +i);
            int colSize = sc.nextInt();
            arr[i] = new int[colSize];
            System.out.println("enter the column values in a row" +i);
            for (int j=0;j<colSize;j++){
                arr[i][j] = sc.nextInt();
            }
        }
        System.out.println("input:");
        for (int i=0;i<arr.length;i++){
            System.out.println(Arrays.toString(arr[i]));
        }
        int[][] outPutArray = new int[arr.length][];
        for(int i=0;i< arr.length;i++){
            outPutArray[i] = new int[arr[i].length];
            for (int j=0; j< arr[i].length; j++){
                outPutArray[i][j] = arr[j][i];
            }
        }
        System.out.println("output:");
        for (int i=0;i<outPutArray.length;i++){
            System.out.println(Arrays.toString(outPutArray[i]));
        }


}
}
