package selenium;

import java.util.Scanner;

public class GoDutch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the total bill amount");
        int billAmount = sc.nextInt();
        System.out.println("enter the number of friends");
        int friends = sc.nextInt();
        if (billAmount<0){
            System.out.println("Bill total amount cannot be negative.");
        }else if(friends<0){
            System.out.println("Number of friends cannot be negative or zero.");

        }
        int serviceCharge = (billAmount *10)/100;
        int amountPerFriend = (serviceCharge+billAmount)/friends;
        System.out.println(amountPerFriend);


    }
}
