package selenium.interfacetopic;

public class Dell implements Laptop{

    public void copy() {
        System.out.println("Dell copy code");
    }

    public void paste() {
        System.out.println("Dell paste code");
    }

    public void cut() {
        System.out.println("Dell cut code");
    }

    public void keyboard() {
        System.out.println("Dell keyboard code");
    }
}
