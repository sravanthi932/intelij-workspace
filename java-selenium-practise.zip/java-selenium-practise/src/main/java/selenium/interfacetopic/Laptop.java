package selenium.interfacetopic;

public interface Laptop {

    public void copy();

    public void paste();

    public void cut();

    public void keyboard();

    //after java 8 we can implement the method not only defining by using default and static both not using public
    default void security() {
        commonCode();
        System.out.println("please implement");
    }
    //out-side the world can also use the static methods
    static void audio(){
        commonCode();
        System.out.println("Laptop audio code");
    }

    private static void commonCode(){
        System.out.println("commonCode");
    }
}
