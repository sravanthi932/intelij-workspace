package selenium.interfacetopic;

public class HP implements Laptop{

    public void copy() {
        System.out.println("HP copy code");
    }

    public void paste() {
        System.out.println("HP paste code");
    }

    public void cut() {
        System.out.println("HP cut code");
    }

    public void keyboard() {
        System.out.println("HP keyboard code");
    }

    public void printer(){
        System.out.println("HP printer code");
    }
}
