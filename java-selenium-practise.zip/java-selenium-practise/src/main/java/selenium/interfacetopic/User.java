package selenium.interfacetopic;

public class User {
    public static void main(String[] args) {
        Lenevo lenevo = new Lenevo();
        lenevo.capture();
        lenevo.copy();
        lenevo.cut();
        lenevo.security();;

        Laptop.audio();

        HP hp = new HP();
        hp.printer();
    }
}
