package selenium.interfacetopic;

public class Lenevo implements Laptop{

    public void copy() {
        System.out.println("lenovo copy code");
    }

    public void paste() {
        System.out.println("lenovo paste code");
    }

    public void cut() {
        System.out.println("lenovo cut code");
    }

    public void keyboard() {
        System.out.println("lenovo keyboard code");
    }

    public void capture(){
        System.out.println("lenovo capture camera code");
    }
    @Override
    public void security(){
         System.out.println("lenovo security");
    }
}
