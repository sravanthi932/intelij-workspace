package selenium;

public class TopicOperator {
    //What is an Operator?
    //Operator is a symbol that perform operations on variables and values.
    public static void main(String[] args) {
        int i = 20;
        int j = 6;
        int k = i++ + ++i + i-- - --i ;//44
        int L = ++i;
        System.out.println(k);
        System.out.println(L);

        //Arithmetic op : Addition(+), Subtraction(-), Multiplication(*), Division(/), Module(%)
        System.out.println(i+j);
        System.out.println(i-j);
        System.out.println(i*j);
        System.out.println(i/j);
        System.out.println(i%j);

        //Unary Op : ++(increment)(pre & post by only one value) --(Decrement)(pre & post)
        System.out.println(i);
        System.out.println(++i);
        System.out.println(i++);
        System.out.println(i);
        System.out.println(j);
        System.out.println(--j);
        System.out.println(j--);
        System.out.println(j);

        //Relation Op : finding the relation b/w the two values.
        //==(equal to)
        //!=(not equal to)
        //>(greater than)
        //<(less than)
        //>=(greater than or equal to)
        //<=(less than or equal to)
//        System.out.println(i==j);
//        System.out.println(i!=j);
//        System.out.println(i>j);
//        System.out.println(i<j);
//        System.out.println(i>=j);
//        System.out.println(i<=j);

        //Conditional Op : make some conditions
        //&&(Conditional AND) ----->
        // T - T = T
        // T - F = F
        // F - T = F
        // F - F = F

        //||(Conditional OR)
        // T - T = T
        // T - F = T
        // F - T = T
        // F - F = F

        System.out.println(i>j && i>=j);//T
        System.out.println(i>j && i==j);//F
        System.out.println(i==j && i>j);//F
        System.out.println(i<j && i<=j);//F
        System.out.println(i>j || i>=j);//T
        System.out.println(i>j || i==j);//T
        System.out.println(i==j || i>j);//T
        System.out.println(i<j || i<=j);//F

        //Assignment Op : Assigning some values (=, +=, -=, *=, /=, %=)
         i += 5;
         i -= 5;
         i *= 4;
         i /= 4;
         i %= 2;

         System.out.println(i);


    }



}
