package selenium;

public class StaticAndNonStaticVariablesTopic {
//1.In JVM we have Memory area and Heap memory.
//2.Memory area stores the 1 static block for 1 class ,
//3.its only create for once, user can call static method in non-static method,
//4.static data is accessible the objects with in the same class(memory sharing),
//5.if user define the static block in the class the firstly going to print static output the next main method.
//6.if user defined the constructor then first going to print constructor and next main method.
//7.if user defined the non-static block in the same class firstly going to print non-static and next constructor.
//8.we cannot access the non-static methods in to static methods.
//note: tried with my butler English

    static {
        System.out.println("static block");
    }
    {
        System.out.println("non-static block");
    }
    public  StaticAndNonStaticVariablesTopic(){
        System.out.println("constructor");
    }


}
