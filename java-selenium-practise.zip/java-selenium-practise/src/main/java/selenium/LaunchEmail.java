package selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LaunchEmail {
    public static void main(String[] args){
        //4bits - 1Nibble
        //8bits - 1Byte

        System.out.println(Short.SIZE/8);
        System.out.println(Byte.SIZE/8);
        System.out.println(Integer.SIZE/8);
        System.out.println(Float.SIZE/8);
        System.out.println(Long.SIZE/8);
        System.out.println(Character.SIZE/8);
        System.out.println(Double.SIZE/8);

        byte b = 20;
        System.out.println(Integer.MAX_VALUE);
        System.out.println(Integer.MIN_VALUE);
    }
}
