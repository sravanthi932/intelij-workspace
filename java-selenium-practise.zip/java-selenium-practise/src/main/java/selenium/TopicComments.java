package selenium;

public class TopicComments {
    //Qn:Comment means?
    /*Comment is a statement that will not be executed by the compiler and Interpreter.
     It can be used to provide information or explanation about the method, variable, class or any statement*/
    //improve the code readability and understandability.
    //qn.types of comments
    //1.Single Comment
    //comment in one line only using '//'
    //2.Multiline comment
    //we can write the comments in multi line '/*  */'
    //3.Document comments.
    // it used to give total explanation about the class, package, method and variable
    //these comments we need to give above the class, package, variable etc.,
    //having some annotations
    /**
     *
     */


}
