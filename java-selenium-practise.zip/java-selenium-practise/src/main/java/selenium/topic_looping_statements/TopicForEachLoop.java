package selenium.topic_looping_statements;

public class TopicForEachLoop {
    //syntax:
    //for(dataType varName: arrayOrCollection){
    //statements
    //}
    //we use foreach only for collections and arrays.
    //value update declared internally.
    public static void main(String[] args) {
        int[] arr = {1,2,3,4,5,6,7,8};
        for (int i=0;i<arr.length;i++){
            System.out.println(arr[i]);
        }
        //multi-dimensional
        int[][] arr1 = {
                {4,5,6},
                {9,8},
                {7,8,9,0,1}
        };
        int sum=0;
        int noOfElements=0;
        for (int[] singleDimensional: arr1) {
            for (int value : singleDimensional){
              sum += value;
              noOfElements++;
            }
        }
        System.out.println(sum);
        System.out.println("avg:" +sum/noOfElements);
    }

}
