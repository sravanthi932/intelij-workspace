package selenium.topic_looping_statements;

import java.util.Scanner;

public class TopicWhile {
    //Qn: Looping statement means
    //Looping statements are the statements that execute one or more statements repeatedly several no.of times.
    //While
    //While(condition){
    //statements
    //}
    public static void main(String[] args) {
        //int i = 0;
//        while(i < 0){
//            System.out.println(i);
//            i++;
//        }
        //do while Syntax:
        //do {
        //statement
        //}
        //while (condition);
//        do {
//            System.out.println(i);
//        }
//        while (i<0);

        //HomeWork
        //1qn.Print 1 to 100 values.
        //using while
//        Scanner sc = new Scanner(System.in);
//        int startValue = sc.nextInt();
//         System.out.println("enter the start value");
 //       int lastValue = sc.nextInt();
//         System.out.println("enter the last value");
  //       int value = startValue;
//        while (value <= 100){
//            System.out.println(value);
//            value++;
//        }
        //using do-while
//        Scanner sc = new Scanner(System.in);
////        int startValue = sc.nextInt();
////         System.out.println("enter the start value");
// //       int lastValue = sc.nextInt();
////         System.out.println("enter the last value");
//  //       int value = startValue;
//        do {
//            System.out.println(value);
//            value++;
//        }
//        while (value <= 100);
        //2qn.print even numbers between 200-500.
        //using While loop
//        Scanner sc = new Scanner(System.in);
//        System.out.println("give the start vale");
//        int startValue = sc.nextInt();
//        System.out.println("give the last vale");
//        int lastValue = sc.nextInt();
        // int value = startValue;
//        while (value <= lastValue){
//            if(value % 2 == 0)
//            System.out.println(value);
//            value++;
//        }
        //using do=while
//        Scanner sc = new Scanner(System.in);
//        System.out.println("give the start vale");
//        int startValue = sc.nextInt();
//        System.out.println("give the last vale");
//        int lastValue = sc.nextInt();
        // int value = startValue;
//        do {
//                if(value % 2 == 0)
//                    System.out.println(value);
//                value++;
//            }
//        while (value <= lastValue);

//        3qn: print the numbers which are divisible by 7 in between 150 to 200;
//        using While loop
//        Scanner sc = new Scanner(System.in);
//        System.out.println("give the start value");
//        int startValue = sc.nextInt();
//        System.out.println("give the last value");
//        int lastValue = sc.nextInt();
        // int value = startValue;
//        while (value <= lastValue){
//            if(value % 7 == 0)
//            System.out.println(value);
//            value++;
//         }

        //using do-while
//        Scanner sc = new Scanner(System.in);
//        System.out.println("give the start value");
//        int startValue = sc.nextInt();
//        System.out.println("give the last value");
//        int lastValue = sc.nextInt();
        // int value = startValue;
//        do {
//                if(value % 7 == 0)
//                    System.out.println(value);
//                value++;
//            }
//        while (value <= lastValue);

        //4qn: Print the prime numbers between the 50 to 150.
        //using While loop
        Scanner sc = new Scanner(System.in);
        System.out.println("give the start value");
        int startValue = sc.nextInt();
        System.out.println("give the last value");
        int lastValue = sc.nextInt();
         int value = startValue;
         while (value <= lastValue) {
             boolean isPrime = true;
             if (value != 1 && value != 2) {
                 int i = 2;
                 while (i < value) {
                     if (value % i == 0) {
                         isPrime = false;
                         break;
                     }
                     i++;
                 }
             }
             else
                 isPrime = false;
             if (isPrime)
                 System.out.println(value);
             value++;
         }
        //5qn.print sum of the even numbers between 40-80.
//        using While loop
//        Scanner sc = new Scanner(System.in);
//       System.out.println("give the start value");
//       int startValue = sc.nextInt();
//        System.out.println("give the last value");
//        int lastValue = sc.nextInt();
//         int value = startValue;
//        int sum = 0;
//        while (value <= lastValue){
//            if(value % 2 == 0)
//           sum += value;
//           value++;
//       }
//        System.out.println("the sum of the even numbers is " +sum);

        //6Qn: Print the odd numbers between 200 to 25(reverse order)
//        Scanner sc = new Scanner(System.in);
//        System.out.println("give the start value");
//        int startValue = sc.nextInt();
//        System.out.println("give the last value");
//        int lastValue = sc.nextInt();
//        int value = startValue;
//        while (value >= lastValue){
//            if(value % 2 != 0)
//                System.out.println(value);
//            value--;
//        }

    }
}
