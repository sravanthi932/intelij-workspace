package selenium.topic_looping_statements;

import java.util.Scanner;

public class Avgvalue {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int average;
        int sum=0;
        int count = 0;
        while (true) {
            int userNumber = sc.nextInt();
            if (userNumber == 0) {
                break;
            }
            sum += userNumber;
            count++;
        }
            average = sum/count;
            System.out.println(average);

    }
}
