package selenium.topic_looping_statements;

import java.util.Scanner;

public class TopicForLoop {
    //Syntax:
    //for(initialization; condition; updation){
    //statements
    //}
    public static void main(String[] args) {
//        for (int i = 1; i < 10; i++){
//            System.out.println(i);
//        }
       // or else
        //we can initialise out-side the for loop.
        //if interviewer ask if-we remove condition and update then we can write like this
//        int i;
//        for ( i = 1; ;){
//            if (i<10){
//                System.out.println(i);
//                i++;
//                i*=2;
//            }
//            else
//               break;
//        }
//        System.out.println(i);


        //HomeWork
        //1qn.Print 1 to 100 values using for loop.
//        Scanner sc = new Scanner(System.in);
//        System.out.println("give the startNumber");
//        int startNumber = sc.nextInt();
//        System.out.println("give the lastNumber");
//        int lastNumber = sc.nextInt();
//        int number = startNumber;
//        int i;
//        for ( i = number; i <= lastNumber; i++ ){
//            System.out.println(i);
//        }

        //2qn.print even numbers between 200-500.
        //using for loop
//        Scanner sc = new Scanner(System.in);
//        System.out.println("give the startNumber");
//        int startNumber = sc.nextInt();
//        System.out.println("give the lastNumber");
//        int lastNumber = sc.nextInt();
//        int number = startNumber;
//        int i;
//        for (i = number; i <= lastNumber; i++){
//            if(i%2==0){
//                System.out.println(i);
//            }
//        }


//       3qn: print the numbers which are divisible by 7 in between150 to 200;
//        using for loop
//        Scanner sc = new Scanner(System.in);
//        System.out.println("give the startNumber");
//        int startNumber = sc.nextInt();
//        System.out.println("give the lastNumber");
//        int lastNumber = sc.nextInt();
//        int number = startNumber;
//        int i;
//        for (i = number; i <= lastNumber; i++){
//            if(i%7==0){
//                System.out.println(i);
//            }
//        }
        //4qn: Print the prime numbers between the 50 to 150.
        //using for loop
//        Scanner sc = new Scanner(System.in);
//        System.out.println("give the startNumber");
//        int startNumber = sc.nextInt();
//        System.out.println("give the lastNumber");
//        int lastNumber = sc.nextInt();
//        int number;
//        for (number = startNumber; number <= lastNumber; number++ ){
//             int noOfDividends = 0;
//            if (number !=1 && number !=2){
//                for (int i=2; i<=number; i++) {
//                    if (number % i == 0)
//                        noOfDividends++;
//                }
//            }
//            if (noOfDividends <=2 && noOfDividends !=0)
//                System.out.println(number);
//        }
        //5qn.print sum of the even numbers between 40-80.
        //using for-loop
//        Scanner sc = new Scanner(System.in);
//        System.out.println("give the startNumber");
//        int startNumber = sc.nextInt();
//        System.out.println("give the lastNumber");
//        int lastNumber = sc.nextInt();
//        int sum = 0;
//        for (int number = startNumber; number <= lastNumber; number++){
//            if(number%2 == 0)
//                sum += number;
//        }
//        System.out.println("sum of the even no is:" +sum);

        //6Qn: Print the odd numbers between 200 to 25(reverse order)
        Scanner sc = new Scanner(System.in);
        System.out.println("give the startNumber");
        int startNumber = sc.nextInt();
        System.out.println("give the lastNumber");
        int lastNumber = sc.nextInt();
        for (int number = startNumber; number >= lastNumber; number--){
            if(number%2 != 0)
                System.out.println(number);
        }

    }
}
