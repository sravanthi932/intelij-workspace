package selenium;

import java.util.Scanner;

public class UserInputFromConsole {
    public static void main(String[] args) {
      //How to get the user input from the console.
      //Get different types of data from the console.
        Scanner sc = new Scanner(System.in);
        System.out.println("Hi, What is your name");
        String name = sc.nextLine();
        System.out.printf("Hey %s, How are you \n", name);
        String status = sc.nextLine();
        System.out.println("What is your age");
        int age = sc.nextInt();
    }
}
