package selenium;

import java.util.Scanner;

public class SnailPractise {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter no.of feet travel up each day");
        int aFeet = sc.nextInt();
        System.out.println("Enter no.of feet snail down each day");
        int bFeet = sc.nextInt();
        System.out.println("enter the height of the tree");
        int height = sc.nextInt();
        if(aFeet <= bFeet && aFeet<height){
            System.out.println("Imposible");
        }else {
            int days = (int) Math.ceil((double) (height-bFeet)/(aFeet-bFeet));
            System.out.println(days);
        }
    }
}
