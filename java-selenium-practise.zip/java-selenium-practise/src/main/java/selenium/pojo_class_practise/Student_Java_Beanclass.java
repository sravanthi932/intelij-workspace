package selenium.pojo_class_practise;

import java.io.Serializable;

//java bean class
public class Student_Java_Beanclass implements Serializable {
    private int rollNO;
    private String name;
    private String section;

    public Student_Java_Beanclass(){

    }
    public Student_Java_Beanclass(int id, String name){

    }

    public int getRollNO() {
        return rollNO;
    }

    public void setRollNO(int rollNO) {
        this.rollNO = rollNO;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }
}
