package selenium.pojo_class_practise;

public class User {
    public static void main(String[] args) {
        Employee ep = new Employee();
        ep.setId(11);
        ep.name = "kannna";
        ep.sal = 45678.0;

        System.out.println(ep.getId());
        System.out.println(ep.name);
        System.out.println(ep.sal);
    }
}
