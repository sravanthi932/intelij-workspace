package selenium.pojo_class_practise;

public class Employee {
    //pojo should not have the main method
    private int id;
    public String name;
    protected double sal;

    public Employee(){

    }
    public Employee(int id){
        this.id = id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}
