package selenium;

import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;

public class String_Topic {
    //String: is a sequence of characters, and it is a class in java but considered as a literal because of its unique behaviour.
    //string pool
    //heap area
    public static void main(String[] args) {
//        String s1= "Sravanthi";
//        String email = "sravanthianumula@932";
//        String s2 = new String("hello");
//        System.out.println(s1);
//        System.out.println(s1+email);
//        System.out.println(new String_Topic());

        String s1 = "hello";
        String s2 = new String("hello");
        String s3 = "hello";
        String s4 = new String("hello");
        //addresses verify
        System.out.println(s1==s2);
        System.out.println(s1==s3);
        System.out.println(s4==s2);
        //data verify
        System.out.println(s1.equals(s2));//true  i.e; data is same so..


        //String methods
        //startsWith
        //endsWith
        //contains
        //equals
        //equalsIgnoreCase
//        String s1 = "hello";
//        String s2 = "HellO";
//        String s3 = "HELLO";
//        System.out.println(s1.equals(s2));//false
//        System.out.println(s1.equalsIgnoreCase(s2));//true
//        System.out.println(s1.contains("he"));//true
//        System.out.println(s1.contains("He"));//false
//        System.out.println(s1.startsWith("he"));//true
//        System.out.println(s1.startsWith("He"));
//        System.out.println(s2.endsWith("lO"));//true
//        System.out.println(s2.endsWith("lo"));//f

        //length
        //trim //removing the spaces from start and last
        //toCharArray
        //toUpperCase
        //toLowerCase
//        String s4 = "hello";
//        String s5 = "HellO";
//        String s6 = " HELLO WORLD  ";
//        System.out.println(s6.length());
//        System.out.println(s6.trim().length());
//        System.out.println(s5.toCharArray());
//        System.out.println(s4.toUpperCase());
//        System.out.println(s6.toLowerCase());
//        System.out.println(s6.trim().toLowerCase());

        //indexOf
        //lastIndexOf
        //subString
        //split
        //charAt
        String s7 = " hi this is sravanthi";
//        System.out.println(s6.indexOf(7));
//        System.out.println(s6.indexOf("L"));//while giving the char we get the index of that char
//        System.out.println(s6.lastIndexOf("L"));
//        System.out.println(s6.substring(3,8));
//        System.out.println(s3.substring(2));
        System.out.println(Arrays.toString(s7.split(" ")));
//        System.out.println(s7.charAt(7));//while giving index we get the char


        //replace
        //replaceAll
        //valueOff
        //isEmpty
        //isBlank
        String s8 = "1243";
//        String s10 = "  ";
//        String s11 = "";
//        int i = Integer.valueOf(s8);
//        System.out.println(s7.replace('s','o'));
//        System.out.println(s7.replaceAll("sravanthi","naveen"));
//        System.out.println(i);
//        int j = 567;
//        String s9 = String.valueOf(j);
//        System.out.println(s9);
//        System.out.println(s10.isBlank());//true
//        System.out.println(s10.isEmpty());//false
//        System.out.println(s10.length());
//        System.out.println(s10.trim().isEmpty());//true
//        System.out.println(s10.trim().length());
//        System.out.println(s11.isBlank());//true
//        System.out.println(s11.isEmpty());

        //HomeWork
        //1qn. Write a java program to count the number of characters in a string.
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("enter your input string");
//        String input = scanner.nextLine();
//        System.out.println("input:");
//        System.out.println("output:" +input.length());
//        System.out.println(input.split(" ").length);

        //2qn. Write the java program to count the number of words in a string.
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("enter your input string");
//        String input = scanner.nextLine();
//        System.out.println("input:");
//        System.out.println("output" +input.split(" ").length);

        //3qn. Write a java program to count the total number of occurrences of a given character in a string.
         Scanner sc = new Scanner(System.in);
         System.out.println("enter your input string");
         String input = sc.nextLine();
         System.out.println("please enter the target character");
         char targetChar = sc.next().charAt(0);
         System.out.println("input:" +input);
         System.out.println("targetCharacter:" +targetChar);
         int count = 0;
         for (int i=0;i<input.length(); i++){
             if(input.charAt(i)==targetChar)
                 count++;
         }
//         //2nd method
//         char[] characters = input.toCharArray();
//         for (int i=0;i<input.length(); i++){
//            if(characters[i] == targetChar)
//                count++;
//        }
         System.out.println("output:" +count);

        //4qn.Write a java program to reverse a string
        Scanner sc1 = new Scanner(System.in);
        System.out.println("enter your string");

        String str = sc1.nextLine();
        System.out.println("input:" +str);
        String revString = "";
        for(int i=str.length()-1; i>=0;i--){
            revString += str.charAt(i);
        }
        System.out.print("output:" +revString);

        //5qn. Write a java program to remove all starting and ending spaces from a string.
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter your input string");
//        String input = sc.nextLine();
//        System.out.println("input:" +input);
//        System.out.println("output:" +input.trim());

        //6Qn. Write a java program to reverse each word in a given string.
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter your input string");
//        String input = sc.nextLine();
//        System.out.println("input:" +input);
//        String[] words = input.split(" ");
//
//        String outputString = "";
//        for (int i=0;i<words.length;i++){
//            String word = words[i];
//            String reverseWord = "";
//            for (int  j=word.length()-1; j>=0; j--){
//                reverseWord += word.charAt(j);
//            }
//            if(1!= words.length-1){
//                outputString += reverseWord + " ";
//            }
//            else
//                outputString += reverseWord;
//
//        }
//        System.out.println("output:" +outputString);

        //7qn: change the odd words to uppercase and reverse the even words
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter your input String");
//        String input = sc.nextLine();
//        System.out.println("input" +input);
//        String[] words = input.split(" ");
//
//        String outputString = " ";
//        for (int i=0;i<words.length; i++){
//            String word = words[i];
//            if(i%2==0)
//                outputString += word.toUpperCase();
//            else
//                outputString += getReverseString(word);
//            if(i!=words.length-1)
//                outputString += " ";
//        }
//        System.out.println("output" +outputString);



        //8Qn: count the uppercase ,lowercase , special characters and digits in the string.
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter your input string");
//        String input = sc.nextLine();
//        System.out.println("input" +input);
//
//        int upperCaseLetterCount = 0;
//        int lowerCaseLetterCount = 0;
//        int digitsCount = 0;
//        int specialCharacterCount = 0;
//
//        char[] characters = input.toCharArray();
//        for (char ch: characters){
//            if(Character.isUpperCase(ch))
//                upperCaseLetterCount++;
//            else if(Character.isLowerCase(ch))
//                lowerCaseLetterCount++;
//            else if(Character.isDigit(ch))
//                digitsCount++;
//            else
//                specialCharacterCount++;
//        }
//           System.out.println("output: ");
//        System.out.println("Uppercase letter count" +upperCaseLetterCount);
//        System.out.println("lowercase letter count" +lowerCaseLetterCount);
//        System.out.println("digits count" +digitsCount);
//        System.out.println("special character count" +specialCharacterCount);

        //9Qn: WAP to find the first repeated and non-repeated characters in the string.
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter your input string");
//        String input = sc.nextLine();
//        System.out.println("input" +input);
//
//        char firstRepeatedChar = ' ';
//        char firstNonRepeatedChar = ' ';
//
//        for (int i=0; i<input.length(); i++){
//            char tempChar = input.charAt(i);
//            if (tempChar != ' ') {
//                   if (input.indexOf(tempChar) == input.lastIndexOf(tempChar)){
//                       if(firstNonRepeatedChar == ' ')
//                           firstNonRepeatedChar = tempChar;
//                   }
//                   else if (firstRepeatedChar == ' ')
//                       firstRepeatedChar = tempChar;
//                   if(firstRepeatedChar != ' ' && firstNonRepeatedChar!= ' ')
//                       break;;
//            }
//        }
//        System.out.println("output:" );
//        System.out.println("First repeated char" +firstRepeatedChar);
//        System.out.println("First Non-repeated char" +firstNonRepeatedChar);

        //10Qn: WAP to create an array using words at odd positions in a string.i
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter your input");
//        String input = sc.nextLine();
//        System.out.println("input:" +input);
//
//        String[] words = input.split(" ");
//        String[] outputArr = new String[words.length/2];
//        int index = 0;
//        for (int i=0; i<words.length; i++){
//            if(i%2 !=0){
//                outputArr[index] =words[i];
//                index++;
//            }
//        }
//        System.out.println(Arrays.toString(outputArr));

        //11Qn: WAP to find the max length word in a given string(if two words are of same
        // length then return first occurring word of max-length)
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter your input string");
//        String input = sc.nextLine();
//        System.out.println("input:" +input );
//
//        String[] words = input.split(" ");
//        String maxLenWord = words[0];
//        for (int i=1; i< words.length; i++){
//            if(maxLenWord.length() < words[i].length())
//                maxLenWord = words[i];
//        }
//        System.out.println("output:" +maxLenWord);

        //12Qn: Compare two strings, if the characters in string 1 are present in String2, then it should
        //be printed as such in output, else '+' should be printed in output.
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter your first input string");
//        String input1 = sc.nextLine();
//        System.out.println("enter your second input string");
//        String input2 = sc.nextLine();
//
//        System.out.println("input1: " +input1);
//        System.out.println("input2: " +input2);
//
//        String output = "";
//        for(int i=0; i<input1.length(); i++){
//            char tempChar = input1.toLowerCase().charAt(i);
//            if(input2.toLowerCase().indexOf(tempChar)>=0)
//                output += input1.charAt(i);
//            else
//                output += '+';
//        }
//        System.out.println("output :" +output);

        //13qn.Given the first and last name, Print the last name first then followed by "," first character of the first name.
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter the first name");
//        String firstName = sc.nextLine();
//        System.out.println("enter the last name");
//        String lastName = sc.nextLine();
//
//        String output = lastName + "," +firstName.charAt(0);
//        System.out.println("output:" +output);


        //14Qn. WAP to print the filename extension in the console.
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter your input string");
//        String input = sc.nextLine();
//        System.out.println("input: " +input);
//
//        String outString = input.substring(input.lastIndexOf("."));
//
//        System.out.println("output:" +outString);

        //15Qn. WAP to verify the given string is palindrome or not.
//        Scanner sc = new Scanner(System.in);
//        System.out.println("enter your input string");
//        String input = sc.nextLine();
//        System.out.println("input: " +input);
//
//        String outputStr = "";
//        if(getReverseString(input).equals(input))
//            outputStr = "It is a palindrome";
//        else
//            outputStr = "It is not a palindrome";
//        System.out.println("output:" +outputStr);
//   }
//    private static String getReverseString(String inputString){
//        String reverseString = "";
//        for ( int j = inputString.length()-1; j>=0; j--){
//            reverseString += inputString.charAt(j);
//        }
//        return reverseString;
    }
}
