package selenium;

public class TopicMethods {
    // 1st Qn.What is method.
    //it is a block of code or collection of statements grouped together to perform a certain task or operation
    // and return the result to the caller if applicable.
    //Syntax for a method: accessModifier static or Non-static returnType methodName(parameters){
    //Method Body }

    static int currentBalance = 1000;

    public static void greetCustomer(){
        System.out.println("Hello, welcome to bank");
    }
    //whenever we want give some input to method we need declare a parameter in the method
    public void deposit(int amount){
        currentBalance =  currentBalance + amount;
        System.out.println("deposited successfully");
    }
    public static void withdrawal(int amount){
        currentBalance =currentBalance - amount;
        System.out.println("withdrawn successfully");
    }
    public int getCurrentBalance(){
        return currentBalance;
    }
    public static void main(String[] args) {
        TopicMethods tp = new TopicMethods();
        greetCustomer();
        System.out.println("current balance:" + tp.getCurrentBalance());
        tp.deposit(500);
        System.out.println("current balance is :" + tp.getCurrentBalance());
        withdrawal(300);
        System.out.println("current balance is :" +tp.getCurrentBalance());
    }

}
