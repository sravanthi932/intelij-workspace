package selenium.abstractclass_topic;

public abstract class SuperAC implements Laptop{

    public void copy() {
        System.out.println("copy code");
    }

    public void paste() {
        System.out.println("paste code");
    }
}
