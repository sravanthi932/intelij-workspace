package selenium.abstractclass_topic;

public class Lenevo extends SuperAC{

    public void cut() {
        System.out.println("cut code");
    }

    public void keyboard() {
         System.out.println("keyboard code");
    }

    public void audio(){
        System.out.println("audio code");
    }

}
