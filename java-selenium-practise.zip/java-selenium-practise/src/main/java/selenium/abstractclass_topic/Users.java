package selenium.abstractclass_topic;

public class Users {
    public static void main(String[] args) {
        Lenevo lenevo = new Lenevo();
        lenevo.cut();
        lenevo.copy();

        //'SuperAC' is abstract; cannot be instantiated
       // SuperAC superAC = new SuperAC();

    }
}
