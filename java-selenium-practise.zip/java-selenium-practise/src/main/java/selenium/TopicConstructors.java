package selenium;

public class TopicConstructors {
    //Qn:Constructor?
    //block of code, but we call this constructor at the time of object creation.
    //or
    //it is a block of code similar to the method. it is called when an instance(object) of the class is created.
    //constructor name should be a class name
    //doesn't have return type.
    //doesn't return any value.
    //default constructors should be public only
    //when we add constructor i.e.,explicit constructor
    //when java automatically have constructor that is implicit constructor(default constructor).
    //when you add parameterized constructor first you need add default constructor.
    //use of constructor: when we want Define-data for the variables at the time of object creation
    //we can't define constructor as a static or non-static.
    //we can declare as a public,protected,private.
    public int i;
     public static void main(String args[]){
         TopicConstructors tc = new TopicConstructors(13);
         System.out.println(tc.i);
     }
     public TopicConstructors(){
       i = 12;
     }
     public TopicConstructors(int a){
         i = a;
     }
}
