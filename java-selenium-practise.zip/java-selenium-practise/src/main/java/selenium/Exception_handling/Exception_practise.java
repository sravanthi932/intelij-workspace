package selenium.Exception_handling;

public class Exception_practise {
    public static void main(String[] args) {
        System.out.println("program execution start");
        int fNumber = 10;
        int sNumber = 0;
        int result = 0;
        /*
        stack trace:
        1.Exception Name
        2.Exception msg
        3.which line number
        4.Method info
         */
        // try block is imp it should have catch or finally at least o block catch and finally block should follow the try block.
        // for checked exceptions we should throws the exception at the beside to the method signature because the java don't know the checked exceptions.
        //so, we should throws that exception
        //ex:public static void main(String[] args)throws FileNotFoundException, Io Exception
        try {
            result = fNumber/sNumber;
        }
       catch (ArithmeticException ae){
            System.out.println(ae.toString());//write a logic to enter this msg into log files.
           throw ae;//throw the exception back to the java(serious exception we can't handled so return to java)
       }
        finally {
            System.out.println("finally block executed");
        }

        System.out.println("output:" +result);
        System.out.println("program execution end");
    }
}
