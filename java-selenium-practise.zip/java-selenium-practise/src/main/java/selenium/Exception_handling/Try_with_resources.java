package selenium.Exception_handling;

import javax.security.auth.login.LoginException;
import java.io.*;

public class Try_with_resources {

    //instead of giving multiple type exception give the parent exception "Exception"
    public static void main(String[] args) throws Exception {
        File file = new File("./sample.txt");
        if (!file.exists())
            file.createNewFile();

        //Only Auto-closable
        //try with resources
        try (
                FileReader fr = new FileReader(file);
                FileInputStream fis = new FileInputStream(file);
                InputStreamReader isr = new InputStreamReader(fis);
                BufferedReader br = new BufferedReader(isr);) {


            String line = new String();
            String text = new String();
            while ((line = br.readLine()) != null) {
                text += line + "\n";
            }
            System.out.println(text);
            int arr[] = {1,2};
            System.out.println(arr[1]/0);
        }
        //multiple catch blocks

//        catch (FileNotFoundException e1){
//            e1.printStackTrace();
//        }
//        catch (ArithmeticException e2){
//            e2.printStackTrace();
//            System.out.println("don't divide by zero");
//        }
        catch (ArrayIndexOutOfBoundsException e3){
            throw new LoginException("while logging getting an error");
        }

        //when using System.exit(0) then finally block doesn't execute
        //When we want with the try catch finally we use the short-cut select as surround with
        finally {
            System.out.println("good");
        }

    }


}
