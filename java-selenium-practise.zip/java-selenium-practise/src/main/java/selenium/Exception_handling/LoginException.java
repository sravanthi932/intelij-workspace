package selenium.Exception_handling;

public class LoginException extends Exception{
    public LoginException(String message){
        super(message);
    }
}
