package selenium;

public class TopicVariables {

    //1Qn: What is a variable
    //1.variables are used to store and present(access) an information regarding that object.
    //Def: variable is a container which holds the value which is used while executing the program.

    //2Qn.diff types variables
    //1.Global variable-----1.1.Instance Variables(Non-static) 1.2.Class Variables(Static)
    //2.Local Variable------2.1.Local Variables 2.2.Parameters

    //Syntax for variable creation: Datatype variable name equal operator(=) variable value;
    //variable define and initialization the value.
    int id = 11; //non-static or instance
    static String name = "Sravanthi";//static //it should be inside the class and outside the method
    public static void main(String[] args) {
        int pinCode = 506349;//local variable
        System.out.println(pinCode);
        //object creation for instance variables(Non-static)
        TopicVariables tp = new TopicVariables();
        System.out.println(tp.id);
        //we don't want to create object for static variables
        System.out.println(name);
        test1(65);
    }
        public static void test1(int height)
        {
            //height is the parameter this variable is declared at the time of method creation we can add that value by calling the method name
            System.out.println(height);
        }
        // naming conventions
        //1.Case sensitive ex: name  ... NAME both are diff
        //when the variable is single word it should be in lower case Ex:name
       //camelcase: when the variable have multiple words Ex: firstName, lastName, stateTelephoneDirectory
       //don't use reserved kw as variable name
       //don't use shortForms ex: fn instead firstName it should be avoid
       //we can use only these special characters $ and _ we can't use at the start stage of the variable(recommended)
       //we can use _ in constants MATH_PI = 3.14 the value of the pie can't change so they are constants.

//      public static void main(String[] args) {

//        // TODO Auto-generated method stub
//
//        String str="This is interview question";
//        String words[]=str.split(" ");
//        for(int i=words.length-1;i>=0;i--){
//            System.out.print(words[i]+" ");
//        }
//    }

}
