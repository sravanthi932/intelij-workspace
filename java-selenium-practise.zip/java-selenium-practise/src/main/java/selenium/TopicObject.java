package selenium;

public class TopicObject {
    //object is an instance of a class.
    //we can create n number of objects in a class.
    //memory of the object to object is different.
    //variables and methods are used that memory location.
    int i;
    int j;
    public TopicObject(){
        i = 12;
        j = 14;
    }
    public TopicObject(int i, int j) {
        this.i = i;
        this.j = j;
    }
    public static void main(String[] args) {
      TopicObject tp = new TopicObject();
      TopicObject tp1 = new TopicObject(43, 56);
      TopicObject tp2 = new TopicObject( 23, 53);
      System.out.println(tp.add());
      System.out.println(tp1.add());
      System.out.println(tp2.add());
    }
    public int add(){
        return i+j;
    }
}
