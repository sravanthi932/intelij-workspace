package selenium.java_basics_epam_learn_portal.arrays_concept;

public class SumOfEvenNOs {
    public static void main(String[] args) {
        int[] vals = new int[]{-2,10,0,5};
        int result = sum(vals);
        System.out.println(result == 8);
    }
    public static int sum(int[] values){
        if(values ==null || values.length ==0){
            return 0;
        }
        int sumOfEvenNos =0;
        for (int element : values){
            if(element %2 ==0){
                sumOfEvenNos += element;
            }
        }
        return sumOfEvenNos;
    }
}
