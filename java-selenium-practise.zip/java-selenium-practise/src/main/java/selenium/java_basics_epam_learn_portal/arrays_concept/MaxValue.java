package selenium.java_basics_epam_learn_portal.arrays_concept;

import java.util.Arrays;
import java.util.Scanner;

public class MaxValue {
    public static void main(String[] args) {
        int[] vals = new int[]{ -2, 0, 10, 5 };
        int result = max(vals);
        System.out.println(result == 5);
    }

    public static int max(int[] values){
      if(values.length==0){
          throw new UnsupportedOperationException("Array must not be empty");
      }
      int maXValue = values[0];
      for (int elemnt : values){
          if(elemnt > maXValue){
              maXValue = elemnt;
          }
      }
      return maXValue;

    }
}
