import java.util.Scanner;

public class Practise {
    public static void main(String args[]) {
       String str = "my name is Sravanthi";
       String words[] = str.split(" ");
       for (int i= words.length-1; i>=0; i--){
           System.out.print(words[i]+" ");
       }
        String revString = " ";
        for(int i=str.length()-1; i>=0; i--){
            revString +=str.charAt(i);
        }
        System.out.print(revString);
    }
}
