import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LaunchGoogle {

        public static void main(String[] args){
            WebDriverManager.chromedriver().setup();
            WebDriver driver = new ChromeDriver();
            driver.get("https://www.amazon.in");
            WebElement menu = driver.findElement(By.xpath("//li[@id='nav_cat_2']"));
            Actions builder = new Actions(driver);
            builder.moveToElement(menu).build().perform();
            WebDriverWait wait = new WebDriverWait(driver, 5);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@class='nav_a nav_item' and .=\"All Books\"]")));
            WebElement menuOption = driver.findElement(By.xpath("//a[@class='nav_a nav_item' and .=\"All Books\"]"));
            menuOption.click();

    }
}
