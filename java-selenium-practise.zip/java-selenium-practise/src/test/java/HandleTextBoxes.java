import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleTextBoxes {
    public static void main(String args[]) throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://github.com/login");
        WebElement userNameTxt = driver.findElement(By.xpath("//input[@id='login_field']"));
        if (userNameTxt.isDisplayed()){
            if (userNameTxt.isEnabled()){
                userNameTxt.sendKeys("SNH");
                String enteredTxt = userNameTxt.getAttribute("value");
                System.out.println(enteredTxt);
                Thread.sleep(3000);
                userNameTxt.clear();
                driver.quit();
            }
            else {
                System.out.println("user name txt is not enabled");
            }
        }else
        {
            System.out.println("user name is not displayed");
        }
    }
}
