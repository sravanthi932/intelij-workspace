import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class FramesHandling {
    public static void main(String args[]) throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.hyrtutorials.com/p/frames-practice.html");
        driver.findElement(By.id("name")).sendKeys("Text1");
        Thread.sleep(2000);
        driver.switchTo().frame("frm1");
        Select course_dd = new Select(driver.findElement(By.id("course")));
        course_dd.selectByVisibleText("Java");
        Thread.sleep(2000);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("frm2");
        driver.findElement(By.id("firstName")).sendKeys("sravanthi");
        Thread.sleep(2000);
        driver.switchTo().defaultContent();
        driver.findElement(By.id("name")).clear();
        driver.findElement(By.id("name")).sendKeys("Text2");
        Thread.sleep(2000);
        driver.quit();


    }
}
