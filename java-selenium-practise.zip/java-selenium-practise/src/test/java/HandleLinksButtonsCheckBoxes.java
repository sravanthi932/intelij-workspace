import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleLinksButtonsCheckBoxes {
    public static void main(String[] args) throws InterruptedException {
        //Handle the Links, Buttons, radio buttons and check boxes
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.hyrtutorials.com/p/basic-controls.html");

        //radiobutton
        WebElement radioButton = driver.findElement(By.id("femalerb"));
        radioButton.click();//checked
        Thread.sleep(3000);
        if (radioButton.isSelected());
        radioButton.click();//un-checked
        Thread.sleep(3000);

        //checkBox
        WebElement checkBox1 = driver.findElement(By.id("englishchbx"));
        checkBox1.click();
        Thread.sleep(3000);
        WebElement checkBox2 = driver.findElement(By.id("hindichbx"));
        checkBox2.click();
        Thread.sleep(3000);
        WebElement checkBox6 = driver.findElement(By.id("frenchchbx"));
        checkBox6.click();//checked
        Thread.sleep(3000);
        if (checkBox2.isSelected());
        checkBox2.click();//un-checked
        Thread.sleep(3000);

        //button
        WebElement button = driver.findElement(By.id("registerbtn"));
        button.click();
        Thread.sleep(3000);
        System.out.println(driver.findElement(By.id("msg")).getText());
        Thread.sleep(3000);

        //link
        driver.findElement(By.linkText("Click here to navigate to the home page")).click();
        Thread.sleep(3000);


    }
}
