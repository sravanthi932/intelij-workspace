package secondTimePractise;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import javax.swing.*;
import java.util.List;

public class AlertsPractise {
    public static void main(String[] args) throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver =new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.hyrtutorials.com/");
        WebElement seleniumPractise = driver.findElement(By.xpath("//a[contains(text(),'Selenium Practice')]"));
        seleniumPractise.click();
        driver.findElement(By.xpath("//a[contains(text(),'Dropdowns')]")).click();
        WebElement courseElement = driver.findElement(By.xpath("//*[@id=\"course\"]"));
        courseElement.click();
        Select courseNameDropDowns = new Select(courseElement);
        List<WebElement> courseDropdownOptions = courseNameDropDowns.getOptions();
        for (WebElement option : courseDropdownOptions){
            System.out.println(option.getText());
        }
        courseNameDropDowns.selectByVisibleText("Java");
        Thread.sleep(10);
        courseNameDropDowns.selectByIndex(1);
        Thread.sleep(10);
//        driver.get("https://www.hyrtutorials.com/p/frames-practice.html");
//        driver.findElement(By.id("name")).sendKeys("text1");
//        driver.switchTo().frame("frm1");
//        Select course = new Select(driver.findElement(By.id("course")));
//        course.selectByVisibleText("Java");
//        Thread.sleep(10);
//        driver.switchTo().defaultContent();
//        driver.findElement(By.id("name")).clear();
//        driver.findElement(By.id("name")).sendKeys("text2");
//        Thread.sleep(20);
//        driver.switchTo().frame("frm2");
//        driver.findElement(By.id("firstName")).sendKeys("sravs");
//        driver.switchTo().defaultContent();
//        driver.findElement(By.id("name")).clear();
//        driver.findElement(By.id("name")).sendKeys("text2");




    }
}
