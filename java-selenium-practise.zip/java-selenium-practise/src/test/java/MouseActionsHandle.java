import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseActionsHandle {
    public static void main(String args[]) throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.spicejet.com/");
        Actions action = new Actions(driver);
        action.moveToElement(driver.findElement(By.xpath("//div[contains(text(),'Add-ons')]"))).build().perform();
        Thread.sleep(3000);
//        Alert alert = driver.switchTo().alert();
//        System.out.println("alert.getText()");
//        alert.dismiss();
       // driver.findElement(By.linkText("Tiers")).click();
        driver.findElement(By.linkText("SpiceMax")).click();
        driver.quit();
    }
}
