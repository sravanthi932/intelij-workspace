import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.List;


public class HandleDropDowns {
    public static void main(String[] args) throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.hyrtutorials.com/");
        Thread.sleep(3000);
        WebElement seleniumPractise = driver.findElement(By.xpath("//a[contains(text(), 'Selenium Practice')]"));
        seleniumPractise.click();
        driver.findElement(By.xpath("//a[contains(text(),'Dropdowns')]")).click();
        WebElement courseElement = driver.findElement(By.id("//select[@id='course']"));
        courseElement.click();
        Select courseNameDropdown = new Select(courseElement);

        List<WebElement> courseNameDropdownOptions = courseNameDropdown.getOptions();
        for (WebElement option : courseNameDropdownOptions){
            System.out.println(option.getText());
        }

        courseNameDropdown.selectByIndex(1);
        Thread.sleep(3000);
        courseNameDropdown.deselectByValue("python");
        Thread.sleep(3000);
        courseNameDropdown.deselectByVisibleText("Javascript");
       // courseNameDropdown

    }
}
