import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.bouncycastle.asn1.x500.style.RFC4519Style.c;

public class HandleFileUploadPopup {
    public static void main(String args[]){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.get("https://html.com/input-type-file/");
        driver.findElement(By.name("fileupload")).sendKeys("C:\\Users\\Sravanthi_Anumula\\Pictures\\sravanthi\\sravanthi.jpeg");

    }
}
