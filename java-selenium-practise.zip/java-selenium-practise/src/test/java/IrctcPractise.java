import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebElement;

public class IrctcPractise {
    public static void main(String[] args) throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.irctc.co.in/nget/train-search");
        Thread.sleep(4000);
        driver.findElement(By.xpath("//label[text()= \"IRCTC\"]/../../../child::div/following-sibling::div/a")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//button[contains(text(), \"LOGIN\")]")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//input[@type='text' and @placeholder='User Name']")).sendKeys("heth567");
        Thread.sleep(4000);
        driver.findElement(By.xpath("//input[@type='password' and @placeholder='Password']")).sendKeys("erty4567");
        Thread.sleep(4000);
       // driver.findElement(By.id("origin")).sendKeys("Warangal");
        //driver.findElement(By.id("destination")).sendKeys("Tirupati");
    }
}
