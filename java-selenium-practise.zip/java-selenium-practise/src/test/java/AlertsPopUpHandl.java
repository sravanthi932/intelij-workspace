import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertsPopUpHandl {
    public static void main(String args[]) throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://mail.rediff.com/cgi-bin/login.cgi");
        driver.findElement(By.name("proceed")).click();
        Alert alert = driver.switchTo().alert();
        System.out.println(alert.getText());
        Thread.sleep(2000);
        alert.accept();
        driver.quit();
        //alert box
//        driver.get("https://www.hyrtutorials.com/p/alertsdemo.html");
//        System.out.println(driver.findElement(By.id("output")).getText());
//        driver.findElement(By.id("alertBox")).click();
//        System.out.println(driver.switchTo().alert().getText());
//        Thread.sleep(3000);
//        driver.switchTo().alert().accept();
//        System.out.println(driver.findElement(By.id("output")).getText());
//        driver.quit();

        //conformation box
//        driver.get("https://www.hyrtutorials.com/p/alertsdemo.html");
//        System.out.println(driver.findElement(By.id("output")).getText());
//        driver.findElement(By.id("confirmBox")).click();
//        System.out.println(driver.switchTo().alert().getText());
//        Thread.sleep(3000);
//        driver.switchTo().alert().accept();
//        System.out.println(driver.findElement(By.id("output")).getText());
//        driver.findElement(By.id("confirmBox")).click();
//        System.out.println(driver.switchTo().alert().getText());
//        Thread.sleep(3000);
//        driver.switchTo().alert().dismiss();
//        System.out.println(driver.findElement(By.id("output")).getText());
//        driver.quit();

        //Prompt box
//        driver.get("https://www.hyrtutorials.com/p/alertsdemo.html");
//        System.out.println(driver.findElement(By.id("output")).getText());
//        driver.findElement(By.id("promptBox")).click();
//        System.out.println(driver.switchTo().alert().getText());
//        Thread.sleep(3000);
//        driver.switchTo().alert().sendKeys("hi this is sravs");
//        Thread.sleep(3000);
//        driver.switchTo().alert().accept();
//        System.out.println(driver.findElement(By.id("output")).getText());
//        driver.quit();

    }
}
