package java8;

import java.util.Arrays;
import java.util.List;

public class LambdaExpression {
    public static void main(String args[]){
        List<String> names = Arrays.asList("konakati", "sravanthi", "naveen", "hethvik");
        names.forEach(name -> System.out.println(name));
        Runnable r = () ->System.out.println("Runnable using lambda");
        new Thread(r).start();
    }
}
