package collections;

import java.util.HashSet;
import java.util.Set;

public class SetPractise {
    public static void main(String args[]) {
    Set<String> s = new HashSet<String>();
    s.add("H");
    s.add("T");
    s.add("H");
    s.add("M");
    System.out.println(s);
    for (String L: s) {
        System.out.println(L);
    }
    System.out.println(s.contains("N"));
    s.remove("M");
    System.out.println(s);
    System.out.println(s.size());

}
}
