package collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;

public class LIstPractise {
    public static void main(String args[]){
        ArrayList<Integer> al = new ArrayList<Integer>();
        for (int i=1; i<=5; i++)
            al.add(i);
            System.out.println(al);
            System.out.println(al.indexOf(4));
            al.remove(3);
            System.out.println(al);
        for (int i=0; i< al.size(); i++)
            System.out.print(al.get(i) + " ");
        System.out.println();

        Stack<String> str = new Stack<String>();
        str.push("Sravanthi");
        str.push("Naveen");
        str.push("Hethvik");
        str.push("Konakati");

        Iterator<String> itr = str.iterator();
        while (itr.hasNext()){
            System.out.print(itr.next()+" ");
        }
        System.out.println();
        str.pop();
        itr = str.iterator();
        while (itr.hasNext()){
            System.out.print(itr.next()+" ");

        }
        List<String> list = new ArrayList<>();
        list.add("Java");
        list.add("Python");
        list.add("C++");
        System.out.println("programming Languages: ");
        for ( String lang : list){
            System.out.println(lang);
        }
        System.out.println("Element at get index is " +list.get(1));
        list.set(1, "Javascript");
        System.out.println("updated list " +list);
        list.remove(2);
        System.out.println("the final list is " +list);



        List<String> list2 = new ArrayList<>();
        list2.add("Java");
        list2.add("JavaScript");
        list2.add("Python");
        list2.add("C++");
        System.out.println(list2);
        list2.set(1, "php");
        System.out.println(list2);
        list2.remove(1);
        System.out.println(list2);
        System.out.println(list2.get(1));
        for (String s : list2){
            System.out.println(s);
        }
    }
}
