package oops;

public class Main {
    public static void main(String args[]){
        Vehicle v = new Car();
        v.accelrate();
        v.brake();
        v.startEngine();
    }
}
