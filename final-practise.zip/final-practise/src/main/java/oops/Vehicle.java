package oops;

abstract class Vehicle {
    abstract void accelrate();

    abstract void brake();

    void startEngine() {
        System.out.println("the engine should start");
    }
}


