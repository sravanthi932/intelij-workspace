package oops;

public interface Add {
    int add(int a, int b);
}

