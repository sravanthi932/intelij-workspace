package oops;

public class Motor {
    public static void main(String args[]){
        Bicycle bc = new Bicycle();
        bc.changeGear(2);
        bc.speedUp(6);
        bc.applyBreaks(2);
        bc.printStates();

    }
}
