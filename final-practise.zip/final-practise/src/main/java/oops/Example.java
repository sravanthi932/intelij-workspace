package oops;

public class Example {
    private final int value;
    int x;
    int y = 100;
    public void setX(int x){
        this.x = x;
    }
    public void callingVariable(){
        System.out.println("value of x:" +this.x);
    }
    public static void main(String args[]){
        Example e = new Example();
        e.setX(6);
        e.callingVariable();
        Example.Example2 e1 = e.new Example2();
        e1.display();
        e1.demo();
        e.show();

    }
   public Example(){
        this(4);
   }
   void show(){
        System.out.println("which refers to parent class method");
   }
    public Example(int value){
        this.value= value;

    }
    public void methodA(){
        this.methodB();
    }
    public void methodB(){
        System.out.println("this is method b");
    }
    class Example2 extends Example {
        int y = 20;
        void show(){
            System.out.println("which refers to child class method");
        }
        Example2(){
            super();
            System.out.println("which refers to child constructor");
        }
        public void display() {
            System.out.println(y);
            System.out.println(super.y);
            super.show();
            show();
        }
        public void demo(){
            System.out.println("the child class value" +this.y);
            System.out.println("the child class value" +super.y);
            super.show();
        }

    }
}
