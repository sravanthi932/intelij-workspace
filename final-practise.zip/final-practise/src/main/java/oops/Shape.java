package oops;

abstract class Shape {
    abstract void draw();
}

