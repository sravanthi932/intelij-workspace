package oops;

public interface Ancestors {
    public void walk();
    public void talk();
}
class Descdent implements Ancestors{

    @Override
    public void walk() {
        System.out.println("can walk");
    }

    @Override
    public void talk() {
        System.out.println("can walk");
    }
}
