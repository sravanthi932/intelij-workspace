package oops;

public class Operation implements Add, Sub{
    @Override
    public int add(int a, int b) {
        return a+b;
    }

    @Override
    public int sub(int a, int b) {
       return a-b;
    }
    public static void main(String args[]){
        Operation op = new Operation();
        System.out.println(op.add(2, 6));
        System.out.println(op.sub(5, 8));
    }
}
