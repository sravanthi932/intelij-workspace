package oops;

public interface Sub {
    int sub(int a, int b);
}
