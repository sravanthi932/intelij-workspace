package oops;

public class Employee {
    String name;
    Float salary;
    public Employee(String name, float salary){
        this.name = name;
        this.salary = salary;
    }
    public String getName(){
        return name;
    }
    public Float getSalary(){
        return salary;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setSalary(Float salary){
        this.salary = salary;
    }
    public void displayDetails(){
        System.out.println("name of the employee " +name);
        System.out.println("salary of the employee " +salary);
    }
    public static void main(String[] args){
     Employee e = new Employee("sravs", 7500);
     e.displayDetails();
    }
}
