package oops;

public class DataEncapsula {
    private String empName;
    private  int sal;
    private int experience;
    public void setEmpName(String newName){
        empName = newName;
    }
    public String getEmpName(){
        return getEmpName();
    }
    public void serSal(int newSal){
        sal = newSal;
    }
    public int getSal(){
        return sal;
    }
    public void setExperience(int newExperience){
        experience = newExperience;
    }
    public int getExperience(){
        return experience;
    }
    public static void main(String args[]){
        DataEncapsula e = new DataEncapsula();
        e.setEmpName("sravs");
        e.serSal(7);
        e.setExperience(4);
        System.out.println(e.getEmpName());
        System.out.println(e.getSal());
        System.out.println(e.getExperience());
    }
}
