package oops;

public class A {
    public void fun(){
        System.out.println("calling fun method in A class");
    }
}
class B{
    public void fun(){
        System.out.println("calling fun method in B class");
    }
}



class MainMethod extends A{
    public static void main(String args[]){

    }
}
