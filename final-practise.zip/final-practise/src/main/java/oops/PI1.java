package oops;

public interface PI1 {
    public void A();
     default void show(){
        System.out.println("default PI1");
    }
}
interface PI2{
    public void B();
    default void show(){
        System.out.println("default PI2");
    }
}
class DI1 implements PI1, PI2 {
    @Override
    public void A(){
        System.out.println("overiding method A");
    }
    @Override
    public void B(){
        System.out.println("overiding method B");
    }
    public void show() {
        PI1.super.show();
        PI2.super.show();
    }
    public void declaredPI1(){
        PI1.super.show();
    }
    public void declaredPI2(){
        PI2.super.show();
    }
    public static void main(String args[]){
        DI1 d = new DI1();
        d.show();
        System.out.println("implementing throudh class"  );
        d.declaredPI1();
        d.declaredPI2();
        d.A();
        d.B();
    }
}
