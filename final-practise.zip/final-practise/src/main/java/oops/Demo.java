package oops;

import net.bytebuddy.implementation.bytecode.Addition;

import java.util.Scanner;
import java.util.Stack;
public class Demo {
    String yourName = "Harsha";


    byte d = 44;
    static String myName = "sravanthi";
    public static void main(String[] args){
        byte d = 20;
         int age = 8;
         boolean kind = false;
         long totalClasses = 6;
          final float pi = 3.14f;
          System.out.println("the value of pi " + pi);
         double si = 43.9876543;
         char emdAlpha = 'z';
         long longNum = age; //implicit typecasting small data type to larger data type.
         int intNum = (int) pi; //explicit typecasting larger data type to smaller data type.
        Demo1 dur = new Demo1();
        dur.m2();
        Demo1.Circle circle = dur.new Circle(); //r.t variable name = obj.new classname
        circle.m1();

        String fName = "Sravanthi";
         System.out.println(age);
         Demo demo = new Demo();
         demo.m1();
         Demo demo1 = new Demo();
         //System.out.println(totalStrength);
         System.out.println(myName);
         System.out.println(fName);
        System.out.println(demo.d);

        demo.m1();
        System.out.println(demo.yourName);
        demo.yourName = "HarshaVardhan";
        Demo.myName = "Naveen";
        System.out.println(myName);
        System.out.println(demo.yourName);
        System.out.println(demo.d);

        int a = 20;
        int b = 30;
        System.out.println("before swapping a = "  + a + ",b =" +b);
        a= a+b;
        b = a-b;
        a = a-b;
        System.out.println("After swapping a=" +a+ ",b=" +b);
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your first number");
        int a1 = sc.nextInt();
        System.out.println("Enter your second number");
        int a2 = sc.nextInt();
        int sum = a1 + a2;
        int difference = a1-a2;
        int product = a1*a2;
        int division = a1 % a2;
        int quotient = a1 / a2;
        System.out.println("the addition of a1 and a2 " +sum);
        System.out.println("the subtraction of a1 and a2 " +difference);
        System.out.println("the multiplication of a1 and a2 " +product);
        System.out.println("the reminder of a1 and a2 " +division);
        System.out.println("the quotient of a1 and a2 " +quotient);

        for( int k=0; k<3; k++){
            System.out.println("the value of k" +k);
        }


    }
    public void m1(){
        int d= 13;
        System.out.println(myName);
        System.out.println("the value of d " +d);
        System.out.println("the value" +this.d);
    }

}
