package oops;

public class Account {
    private long actNo;
    private String name;
    private String email;
    private float amount;
    public long getActNo(){
        return actNo;
    }
    public void setActNo(long actno){
       this.actNo = actno;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return name;
    }
    public String getEmail(){
        return email;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public float getAmount(){
        return amount;
    }
    public void setAmount(float amount){
        this.amount = amount;
    }
    public static void main(String args[]){
        Account a = new Account();
        a.setActNo(23456789876543l);
        a.setName("sravs");
        a.setEmail("anu@1334");
        a.setAmount(456);
        System.out.println(a.getActNo());
        System.out.println(a.getName());
        System.out.println(a.getEmail());
        System.out.println(a.getAmount());
    }
}

