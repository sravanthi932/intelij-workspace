package oops;

public class Casting {

    public static void main(String[] args){
        int a = 3;
        int b = 5;
        int sum = a+b;
        double result = sum;
        System.out.println("the result is:" +result);
        String height = "3.8f";
        double height1 = Double.parseDouble(height);
        System.out.println(height1);
        Casting.m1();
        Casting cs = new Casting();
        cs.printSchoolName("zpss");


    }
    public int addNumbers(int a, int b){
          return a+b;
    }
    public void message(String name){
        System.out.println(name);
    }
    public void greet(){
        System.out.println("hi! good morning");
    }
    private void secrete(){
        System.out.println("my pin is private");
    }
    protected void id(){
        System.out.println("my id should be protected");
    }
    public void printSchoolName(String name){
        System.out.println("the school name is:" +name);
    }
    public static void m1(){
        System.out.println("my name is");
    }

    private int age;
    public int setAge(){
     return this.age;
    }
    public void setAge(int age){
        this.age = age;
    }
}
