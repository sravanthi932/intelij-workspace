package oops;

public class Car extends Vehicle {

    @Override
    void accelrate() {
        System.out.println("we should accelrate first");
    }

    @Override
    void brake() {
        System.out.println("we should give brake when it is required");
    }

}

