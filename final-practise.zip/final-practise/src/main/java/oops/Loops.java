package oops;

public class Loops {
    public static void main(String[] args){
        int sum = 0;
        for (int i=0; i<=20; i++){
            sum = sum +i;
            System.out.println("Hello World");
        }
        System.out.println("sum " +sum);
        for( int j = 1; j <= 3; j++){
            for (int k = 1; k<= 3; k++){
                System.out.print("(" + j + " , " + k + ")");
            }
            System.out.println();
        }
        int m = 0;
        while (m <= 5){
            System.out.println(m);
            m++;
        }
        int n = 5;
        do {
            System.out.println(n);
            n++;
        }while ( n < 2);{

        }
        int s = 0;
        int i = 0;
        while( i<= 5){
           s = s+i;
           i++;
        }
        System.out.print(s);
    }
}
