package oops;

public class MeyhodPractise {
    public void method(){
        System.out.println("hello");
    }
    public static void gret(){
        System.out.println("Good Morning");
    }
    public static void main(String args[]){
        MeyhodPractise mp = new MeyhodPractise();
        mp.method();
        gret();
    }
}
