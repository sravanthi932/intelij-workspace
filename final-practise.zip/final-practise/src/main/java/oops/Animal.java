package oops;

abstract class Animal {
    private String name;
    public Animal(String name){
        this.name = name;
    }
    public String getName(){
        return name;
    }
    abstract void makeSound();
}
class Dog extends Animal{

    public Dog(String name) {
        super(name);
    }

    @Override
    void makeSound() {
        System.out.println(getName() + "bark");
    }
}
class Cat extends Animal{

    public Cat(String name) {
        super(name);
    }

    @Override
    void makeSound() {
        System.out.println(getName() + "mewm");
    }
}
class MainClass{
    public static void main(String args[]){
        Animal a = new Dog("ABC");
        a.getName();
        a.makeSound();
        Animal b = new Cat("XYZ");
        b.getName();
        b.makeSound();

    }
}
