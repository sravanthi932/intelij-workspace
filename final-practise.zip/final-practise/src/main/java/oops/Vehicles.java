package oops;

public interface Vehicles {
    public void changeGear(int a);
    public  void speedUp(int a);
    public void applyBreaks(int a);
}

