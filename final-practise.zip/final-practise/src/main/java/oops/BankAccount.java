package oops;

public class BankAccount {
    private double balance;

    public BankAccount(int initialBalance){
        if(initialBalance > 0){
            this.balance = initialBalance;
        }
    }
    public double getBalance(){
        return balance;
    }
    public void deposit(int amount){
        if(amount > 0){
            balance += amount;
        }
    }
    public void withDraw(int amount){
        if(amount > 0 && amount <= balance){
            balance -= amount;
        }
    }
    public static void main(String args[]) {
        BankAccount b = new BankAccount(500);
        System.out.println("the initial amount " +b.getBalance());
        b.deposit(200);
        System.out.println("After deposit the amount is: " +b.getBalance());
        b.withDraw(300);
        System.out.println("After withdrawl the amount is: " +b.getBalance());
    }
}
