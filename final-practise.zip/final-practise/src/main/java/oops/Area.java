package oops;

public class Area {
    private int l;
    private int b;
    Area(int l, int b){
        this.l=l;
        this.b=b;
    }
    public void getArea(){
        int area = l*b;
        System.out.println(area);
    }
    public static void main(String args[]){
        Area a = new Area(3, 5);
         a.getArea();
    }
}
