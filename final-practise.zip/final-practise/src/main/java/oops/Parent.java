package oops;

public class Parent {
    int i = 10;
    Parent(){
        System.out.println("the parent constructor");
    }
    void display(){
        System.out.println("parent method");
    }
    class Child extends Parent {
        int i = 20;
        Child(){
            super();
            System.out.println("the child class constructor");
        }
        void display(){
            System.out.println("the child class value" +i);
            System.out.println(("the parent clas value" +super.i));
            super.display();
        }

    }
    public static void main(String args[])
    {

        Parent p = new Parent();
        Parent.Child c = p.new Child();
        c.display();


    }
}
