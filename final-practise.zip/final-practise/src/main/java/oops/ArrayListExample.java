package oops;

import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.IntStream;
import java.util.ArrayList;

public class ArrayListExample {
    public static void main(String args[]){
//        ArrayList<Integer> ar1 = new ArrayList<>();
//        ar1.add(1);
//        ar1.add(2);
//        ar1.add(3);
//        ar1.add(4);
//        System.out.println(ar1);
//        ar1.remove(3);
//        ar1.set(2, 4);
//        System.out.println(ar1);
//        int[] arr = new int[5];
//        for (int i=0; i<arr.length; i++){
//            arr[i] = i+1;
//            System.out.println(arr[i]);
//        }
//       int[] arr1 = IntStream.range(1,5).toArray();
//        for (int i=0; i<arr1.length; i++) {
//            System.out.println(arr1[i]);
//        }
//        System.out.println("");
//
//        int[] arr2 = IntStream.of(1,2, 3,4).toArray();
//        for (int i=0; i<arr2.length; i++){
//            System.out.println(arr2[i]);
//        }
//        int[] arr3 = IntStream.rangeClosed(1,3).toArray();
//        for (int i=0; i<arr3.length; i++){
//            System.out.println(arr3[i]);
//        }
//        int[][] arr4 = { {1, 2},{3, 4} };
//        for(int i=0; i< 2; i++){
//            for (int j=0; j< 2; j++)
//                System.out.print(arr4[i][j] +" ");
//                System.out.println();
//
//
//        }
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter no.of rows");
//        int rows = sc.nextInt();
//        System.out.println("Enter no.of columns");
//        int cols = sc.nextInt();
//        int[][] arr = new int[rows][cols];
//        System.out.println("Enter the data in rows and cols");
//        for (int i=0;i<rows; i++){
//            for (int j= 0; j<cols; j++){
//                arr[i][j] = sc.nextInt();
//            }
//        }
//        System.out.println("elements are");
//        for (int i=0;i<rows;i++){
//            for (int j=0; j<cols;j++){
//                System.out.print(arr[i][j] +" ");
//            }
//            System.out.println();
//        }
//        sc.close();

        int array[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int target = 8;
        int count =0;
        for (int num: array){
            if(num == target){
                count++;
            }
            System.out.println("the element" +target+ "and" +count+ "is");
        }
        int index = search(array, target);
        if(index != -1){
            System.out.println("if the element exist print the index " +index);

        }
        else {
            System.out.println("the target element not exist");
        }
        System.out.println("oroginal array");
        for (int num: array){
            System.out.println(num);

//        int min = array[0];
//        int max = array[0];
//        for (int j =1; j<array.length; j++){
//            if(array[j] < min){
//                min = array[j];
//            }
//            if (array[j] > max){
//                max = array[j];
//            }
//        }
//        System.out.println(min);
//        System.out.println(max);
//        int sum = 0;
//        for(int i=0; i<array.length; i++){
// //           sum += array[i];
//            System.out.println(array[i]);
//
//
//            System.out.println();
//            System.out.println(Arrays.stream(array).max());
//            System.out.println(Arrays.stream(array).min());
//
        }
        reverseArray(array);
        System.out.println("reverse array is");
        for (int num: array){
            System.out.println(num);
        }
//        System.out.println(sum);


    }
    public static void reverseArray(int array[]){
        int start = 0, end = array.length-1;
        while (start < end) {
            int temp = array[start];
            array[start] = array[end];
            array[end] = temp;
            start++;
            end--;
        }
    }
    public static int search(int[] array, int target){
        for (int i=0; i<array.length;i++) {
            if (array[i] == target) {
                return i;
            }

        }
        return -1;
    }

}
