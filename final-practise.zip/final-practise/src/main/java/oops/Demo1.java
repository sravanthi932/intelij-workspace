package oops;

public class Demo1 extends Shape {
    public static void main(String[] args){
        Demo1 d1 = new Demo1();
        d1.m2();
    }
    public void m2(){
        System.out.println(Demo.myName);
       // System.out.println(Demo.totalStrength);
        Demo1 d = new Demo1();
        Demo.myName = "Hethvik";
        System.out.println(Demo.myName);
    }
    public class Circle{
        int a = 10;
        public void m1(){
            System.out.println("hii");
        }
    }

    @Override
    void draw() {
        System.out.println("the shape is circle");
    }
}
