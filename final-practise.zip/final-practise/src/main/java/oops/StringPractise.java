package oops;

import java.util.LinkedHashSet;

public class StringPractise {
    public static void main(String args[]){
        String str = new String("Sravs");
        System.out.println("the string is "+str);
        String s1 = "Knowledge";
        System.out.println(s1);
        System.out.println(s1.hashCode());
        String s2 = "Knowledge";
        s1 = s1.concat("base");
        System.out.println(s1);
        System.out.println(s1.hashCode());

        String s3 = "Sravanthi Naveen";
        String s4 = "Anumula";
        String s5 = s3.concat(s4);
        System.out.println(s5);
        String s6 = "SRAVANTHI aAVEEN";
        char target = 'A';
        int count =0;
        for (int i=0;i<s6.length(); i++){
        if(s6.charAt(i)== target) {
            count++;
        }
        }
        System.out.println("the repeated character count is: " +count);
        //System.out.println(s5.concat(s6));
        System.out.println(s5.length());
        System.out.println(s3.charAt(5));
        System.out.println(s3.substring(3));
        System.out.println(s3.substring(0,4));
        System.out.println(s3.indexOf("N"));
        System.out.println(s3.indexOf("N", 10));
        System.out.println(s3.lastIndexOf("n"));
        System.out.println(s3.toLowerCase());
        System.out.println(s3.toUpperCase());
        System.out.println(s3.toCharArray());
        System.out.println(s3.trim());

        StringBuffer sb = new StringBuffer();
        System.out.println(sb.capacity());
        sb.append("Sravanthi");
        System.out.println(sb.capacity());
        sb.append(" ");
        sb.append("Konakati");
        System.out.println(sb.capacity());
        System.out.println(sb.length());
        String str1 = sb.toString();
        System.out.println(str1);
        StringBuffer sb1 = new StringBuffer("Welcome");
        sb1.append(" Java");
        System.out.println( sb1);
        sb1.insert(2, "python");
        System.out.println(sb1);
        sb1.replace(2, 5, "Hii");
        System.out.println(sb1);
        sb1.delete(2, 5 );
        System.out.println(sb1);
        System.out.println(sb1.reverse());
        System.out.println(sb1.capacity());
        StringBuffer sbr5 = new StringBuffer();
        sbr5.append("Hello");
        System.out.println(sbr5.reverse());
        String s = "madam1";
        String reverse = new StringBuffer(s).reverse().toString();
        System.out.println("is palindrome " +s.equals(reverse));

        String input = "Sravanthi";
        input = input.toLowerCase();
        int vowels =0, consonants = 0;
        for(char c : input.toCharArray()){
            if ("aeiou".indexOf(c)!=-1){
                vowels++;
            }else{
                consonants++;
            }
        }
        System.out.println("vowels are: " +vowels+ " consonants are: " +consonants);
        String name = "sravanthi";
        StringBuffer sbResult = new StringBuffer();
        LinkedHashSet<Character> set = new LinkedHashSet<>();
        for(char c : name.toCharArray()){
            if(set.add(c)){
                sbResult.append(c);
            }
        }
        System.out.println("String without duplicates " + sbResult.toString());

        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("Sravanthi Anumula");
        System.out.println(stringbuilder.reverse());

        String input1 = "hi this is sravanthi";
        System.out.println("the original string is: " +input1);

        String reverseWord = reverseEachWord(input1);
        System.out.println("the reversed string is " +reverseWord);

        System.out.println(transforming(input1));

    }
    public static String reverseEachWord(String str){
        String[] words = str.split(" ");
        StringBuilder result = new StringBuilder();
        for (String word : words){
            StringBuilder originalWord = new StringBuilder(word);
            result.append(originalWord.reverse()).append(" ");
        }
        return result.toString().trim();
    }
    public static String transforming(String str){
        String[] words = str.split(" ");
        StringBuilder sb = new StringBuilder();
        for (int i=0; i< words.length;i++){
            if(i%2==0){
                sb.append(words[i].toUpperCase());
            }
            else{
                sb.append(new StringBuilder(words[i]).reverse());
            }
            if(i < words.length-1){
                sb.append(" ");
            }
        }
        return sb.toString();


    }




}
