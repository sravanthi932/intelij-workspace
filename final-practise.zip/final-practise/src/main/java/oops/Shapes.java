package oops;

public interface Shapes {
    public double calculateArea();
}
class Circle implements Shapes{
    private double r;
    public Circle( double r){
        this.r = r;
    }

    @Override
    public double calculateArea() {
       return Math.PI*r*r;
    }
}
class Rectangle implements Shapes{
    private double length;
    private double width;
    public Rectangle(double length, double width){
        this.length = length;
        this.width = width;
    }

    @Override
    public double calculateArea() {
        return length * width;
    }
}
class ToImplementMain{
    public static void main(String args[]){
        Circle c = new Circle(3.0);
        System.out.println("the area of circle " + c.calculateArea());
        Rectangle r = new Rectangle(4.0, 5.0);
        System.out.println(r.calculateArea());
    }
}