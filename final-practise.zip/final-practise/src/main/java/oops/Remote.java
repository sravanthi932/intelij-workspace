package oops;

abstract class Remote {
    abstract void tvOn();
    abstract void tvOff();
}
class TV extends Remote{

    @Override
    void tvOn() {
        System.out.println("tv is on");
    }

    @Override
    void tvOff() {
         System.out.println("tv is off");
    }
    public static void main(String args[]){
        TV t = new TV();
        t.tvOff();
        t.tvOn();
    }
}
